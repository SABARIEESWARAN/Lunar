from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
from .service import (
    start_analysis_job,
    get_job_status,
    propose_repair,
    get_diff,
    approve_repair,
    reject_repair,
    run_verification,
)

app = FastAPI(title="LUNAR API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeRequest(BaseModel):
    repo_url: str


class RepairRequest(BaseModel):
    job_id: str
    finding_id: str


@app.get("/health")
def health():
    return {"status": "ok", "service": "lunar"}


# ── Analysis ──────────────────────────────────────────────────────────────────

@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    try:
        return start_analysis_job(req.repo_url)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/analyze/{job_id}")
def analyze_status(job_id: str):
    job = get_job_status(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


# ── Repair ────────────────────────────────────────────────────────────────────

@app.post("/api/repair")
def repair(req: RepairRequest):
    try:
        return propose_repair(req.job_id, req.finding_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/repair/{repair_id}/diff")
def diff(repair_id: str):
    result = get_diff(repair_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Repair not found")
    return result


@app.post("/api/repair/{repair_id}/approve")
def approve(repair_id: str):
    result = approve_repair(repair_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Repair not found")
    return result


@app.post("/api/repair/{repair_id}/reject")
def reject(repair_id: str):
    result = reject_repair(repair_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Repair not found")
    return result


# ── Verification ──────────────────────────────────────────────────────────────

@app.post("/api/verify/{repair_id}")
def verify(repair_id: str):
    try:
        return run_verification(repair_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
