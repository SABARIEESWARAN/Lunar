"""
LUNAR Scanners — Three independent analysis agents.

Agent 1: Code Intelligence  — complexity, duplication, maintenance markers
Agent 2: Security & Dependency — credentials, risky patterns, dep versions
Agent 3: Tests & Documentation — coverage gaps, missing docs

Design rules:
- Every finding must cite evidence (file + line when available).
- No finding without a specific piece of repository evidence.
- Duplicate findings for the same construct are suppressed.
- IDs are agent-prefixed: C (code), S (security), T (test/docs).
"""

import ast
import re
from pathlib import Path

TEXT_EXTS = {".py", ".js", ".jsx", ".ts", ".tsx", ".json", ".md", ".txt"}
CODE_EXTS = {".py", ".js", ".jsx", ".ts", ".tsx"}
IGNORED = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build"}


# ─── Shared helpers ────────────────────────────────────────────────────────────

def iter_source(repo, exts=None):
    target_exts = exts or TEXT_EXTS
    for p in sorted(repo.rglob("*")):
        if (
            p.is_file()
            and p.suffix.lower() in target_exts
            and not any(x in p.parts for x in IGNORED)
        ):
            try:
                yield p, p.read_text(errors="ignore")
            except Exception:
                pass


def _rel(repo, path):
    """Return a clean forward-slash relative path."""
    try:
        return str(path.relative_to(repo)).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def finding(fid, category, severity, title, path, line, evidence, recommendation, effort, risk, confidence=0.9):
    """
    Canonical LUNAR finding schema.
    confidence: 0.0–1.0, used by the debt analyst for priority scoring.
    """
    return {
        "id": fid,
        "category": category,
        "severity": severity,
        "title": title,
        "path": str(path),
        "line": line,
        "evidence": str(evidence)[:500],
        "recommendation": recommendation,
        "estimated_effort_min": effort,
        "risk": risk,
        "confidence": confidence,
    }


def _line_of(text, offset):
    """Return 1-based line number for a character offset."""
    return text[:offset].count("\n") + 1


# ─── Agent 1: Code Intelligence ────────────────────────────────────────────────

def scan_code(repo):
    """
    Code Intelligence Agent.
    Detects: complexity, large files, duplication, maintenance markers, error-handling gaps.
    """
    out = []
    idx = 1
    seen_constructs = set()   # deduplicate findings on same function/file
    seen_lines = {}           # for duplication heuristic

    for p, text in iter_source(repo, CODE_EXTS):
        rel = _rel(repo, p)

        # ── Python AST analysis ─────────────────────────────────────────────
        if p.suffix == ".py":
            try:
                tree = ast.parse(text, filename=str(p))
            except SyntaxError as e:
                key = f"syntax:{rel}"
                if key not in seen_constructs:
                    seen_constructs.add(key)
                    out.append(finding(
                        f"C{idx}", "maintainability", "CRITICAL", "Syntax error",
                        p, e.lineno,
                        f"SyntaxError at line {e.lineno}: {e.msg}",
                        "Repair syntax before any other maintenance work.",
                        15, "HIGH", confidence=1.0,
                    ))
                    idx += 1
                continue

            for node in ast.walk(tree):
                if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue

                fn_name = node.name
                fn_line = node.lineno
                fn_end = getattr(node, "end_lineno", node.lineno)
                fn_size = fn_end - fn_line + 1

                # Large function
                key = f"largefn:{rel}:{fn_name}"
                if fn_size >= 50 and key not in seen_constructs:
                    seen_constructs.add(key)
                    out.append(finding(
                        f"C{idx}", "complexity", "HIGH", "Large function",
                        p, fn_line,
                        f"Function '{fn_name}' spans {fn_size} lines (line {fn_line}–{fn_end}). "
                        f"Long functions are harder to test, review, and maintain.",
                        "Break into smaller, single-responsibility functions.",
                        45, "MEDIUM", confidence=0.95,
                    ))
                    idx += 1

                # High cyclomatic complexity
                branches = sum(
                    isinstance(n, (ast.If, ast.For, ast.While, ast.Try, ast.BoolOp, ast.ExceptHandler))
                    for n in ast.walk(node)
                )
                key = f"complexity:{rel}:{fn_name}"
                if branches >= 8 and key not in seen_constructs:
                    seen_constructs.add(key)
                    out.append(finding(
                        f"C{idx}", "complexity", "HIGH", "High cyclomatic complexity",
                        p, fn_line,
                        f"Function '{fn_name}' at line {fn_line} has {branches} control-flow "
                        f"constructs (if/for/while/try/bool). High complexity correlates with bug rate.",
                        "Extract decision logic into named helper functions. Add a test per branch.",
                        60, "MEDIUM", confidence=0.9,
                    ))
                    idx += 1

                # Weak error handling: bare except or pass-only except
                for child in ast.walk(node):
                    if isinstance(child, ast.ExceptHandler):
                        # bare `except Exception: return None` or `pass`
                        body_ops = [type(s) for s in child.body]
                        is_silent = body_ops in [[ast.Pass], [ast.Return]]
                        if is_silent:
                            key = f"silentexcept:{rel}:{fn_name}:{child.lineno}"
                            if key not in seen_constructs:
                                seen_constructs.add(key)
                                out.append(finding(
                                    f"C{idx}", "maintainability", "MEDIUM", "Silent exception handler",
                                    p, child.lineno,
                                    f"Function '{fn_name}': except block at line {child.lineno} "
                                    f"silently swallows exceptions (only contains "
                                    f"{'pass' if ast.Pass in body_ops else 'return None'}).",
                                    "Log or re-raise the exception. Silent swallowing hides bugs.",
                                    20, "MEDIUM", confidence=0.85,
                                ))
                                idx += 1

        # ── Large file check (all source files) ─────────────────────────────
        lines = text.splitlines()
        if len(lines) > 400:
            key = f"largefile:{rel}"
            if key not in seen_constructs:
                seen_constructs.add(key)
                out.append(finding(
                    f"C{idx}", "maintainability", "MEDIUM", "Large source file",
                    p, 1,
                    f"{rel} has {len(lines)} lines. Files over 400 lines become harder to navigate.",
                    "Split the module around distinct responsibilities.",
                    90, "MEDIUM", confidence=0.8,
                ))
                idx += 1

        # ── Maintenance markers ──────────────────────────────────────────────
        for m in re.finditer(r"\b(TODO|FIXME|HACK)\b", text, re.IGNORECASE):
            line_no = _line_of(text, m.start())
            # Get the full line for context
            line_text = text.splitlines()[line_no - 1].strip() if line_no <= len(text.splitlines()) else ""
            key = f"marker:{rel}:{line_no}"
            if key not in seen_constructs:
                seen_constructs.add(key)
                out.append(finding(
                    f"C{idx}", "maintenance", "LOW", "Maintenance marker",
                    p, line_no,
                    f"{m.group(0)} at line {line_no}: {line_text[:120]}",
                    "Convert to a tracked issue or implement the missing work.",
                    20, "LOW", confidence=1.0,
                ))
                idx += 1

    # ── Duplication heuristic ────────────────────────────────────────────────
    # Collect non-trivial lines per file, then find cross-file repeats
    file_lines: dict = {}
    for p, text in iter_source(repo, CODE_EXTS):
        rel = _rel(repo, p)
        for i, raw_line in enumerate(text.splitlines(), 1):
            stripped = raw_line.strip()
            # Only flag substantive lines (skip blanks, comments, short lines, imports)
            if (
                len(stripped) >= 35
                and not stripped.startswith("#")
                and not stripped.startswith("import ")
                and not stripped.startswith("from ")
                and not stripped.startswith('"""')
                and not stripped.startswith("'''")
            ):
                normalised = re.sub(r"\s+", " ", stripped)
                if normalised not in file_lines:
                    file_lines[normalised] = (rel, i, p)
                else:
                    prev_rel, prev_line, prev_p = file_lines[normalised]
                    if prev_rel != rel:
                        key = f"dup:{normalised[:40]}"
                        if key not in seen_constructs:
                            seen_constructs.add(key)
                            out.append(finding(
                                f"C{idx}", "duplication", "MEDIUM", "Duplicated code line",
                                p, i,
                                f"Line {i} in {rel} is identical to line {prev_line} in {prev_rel}: "
                                f'"{stripped[:100]}"',
                                "Extract the shared logic into a single reusable function or module.",
                                30, "MEDIUM", confidence=0.75,
                            ))
                            idx += 1

    return out


# ─── Agent 2: Security & Dependency ───────────────────────────────────────────

def scan_security(repo):
    """
    Security & Dependency Agent.
    Detects: hard-coded credentials, risky dynamic execution,
             injection patterns, suspicious dependency versions.
    Does NOT invent CVEs. External advisory verification is flagged separately.
    """
    out = []
    idx = 1
    seen = set()

    # ── Pattern-based security scan ─────────────────────────────────────────
    # Each entry: (regex, title, recommendation, severity, effort_min, risk, confidence)
    patterns = [
        (
            r'(?i)(password|passwd|db_pass|secret|api[_-]?key|token)\s*=\s*["\'][^"\']{4,}["\']',
            "Hard-coded credential",
            "Move secrets to environment variables (os.environ.get) or a dedicated secrets manager. "
            "Never commit credentials to source control.",
            "HIGH", 30, "HIGH", 0.9,
        ),
        (
            r'(?i)\beval\s*\(',
            "Dynamic code execution via eval()",
            "Remove eval() or replace with a safe alternative (ast.literal_eval for data, "
            "explicit dispatch tables for logic). eval() with untrusted input is a code-injection risk.",
            "CRITICAL", 60, "HIGH", 0.95,
        ),
        (
            r'(?i)\bexec\s*\(',
            "Dynamic code execution via exec()",
            "Remove exec() or strictly validate and sandbox inputs. exec() with user-controlled "
            "data is a critical security risk.",
            "CRITICAL", 60, "HIGH", 0.95,
        ),
        (
            r'(?i)subprocess\.(call|run|Popen)\s*\(.*shell\s*=\s*True',
            "Shell injection risk",
            "Use shell=False and pass arguments as a list. shell=True with variable input "
            "is vulnerable to shell injection.",
            "HIGH", 45, "HIGH", 0.85,
        ),
        (
            r'(?i)(jwt|token)\s*=\s*["\'][A-Za-z0-9+/=._-]{20,}["\']',
            "Hard-coded token or JWT",
            "Remove the hard-coded token and load from environment or secrets manager.",
            "HIGH", 30, "HIGH", 0.85,
        ),
    ]

    for p, text in iter_source(repo, CODE_EXTS | {".json", ".yaml", ".yml", ".env"}):
        rel = _rel(repo, p)
        for pat, title, rec, sev, eff, risk, conf in patterns:
            for m in re.finditer(pat, text):
                line_no = _line_of(text, m.start())
                key = f"sec:{title[:20]}:{rel}:{line_no}"
                if key not in seen:
                    seen.add(key)
                    out.append(finding(
                        f"S{idx}", "security", sev, title,
                        p, line_no,
                        f'Line {line_no}: {m.group(0)[:120]}',
                        rec, eff, risk, confidence=conf,
                    ))
                    idx += 1

    # ── Dependency version checks ────────────────────────────────────────────
    req_file = repo / "requirements.txt"
    if req_file.exists():
        text = req_file.read_text(errors="ignore")
        for line_no, line in enumerate(text.splitlines(), 1):
            line = line.strip()
            # Flag pinned old versions of known packages with maintenance concerns
            OLD_VERSIONS = {
                "fastapi": ("0.95", "FastAPI 0.95.x is several minor versions behind. "
                            "Upgrade for security patches and Pydantic v2 support."),
                "requests": ("2.28", "requests 2.28.x is outdated. Upgrade to 2.31+ for security fixes."),
                "django": ("3.", "Django 3.x is end-of-life. Upgrade to Django 4.2 LTS or 5.x."),
                "flask": ("1.", "Flask 1.x is end-of-life. Upgrade to Flask 2.x or 3.x."),
                "pymongo": ("4.3", "pymongo 4.3.x has known issues. Upgrade to 4.5+."),
                "pydantic": ("1.", "Pydantic v1 is legacy. Upgrade to Pydantic v2 for performance "
                             "and active maintenance."),
            }
            for pkg, (old_ver, note) in OLD_VERSIONS.items():
                if pkg in line.lower() and "==" in line:
                    pinned = line.split("==")[-1].strip()
                    if pinned.startswith(old_ver):
                        key = f"dep:{pkg}:{old_ver}"
                        if key not in seen:
                            seen.add(key)
                            out.append(finding(
                                f"S{idx}", "dependency", "MEDIUM",
                                f"Outdated dependency: {pkg}",
                                req_file, line_no,
                                f"Line {line_no}: {line} — {note}",
                                f"Upgrade {pkg} to the current supported version. "
                                f"Review the changelog for breaking changes before upgrading.",
                                30, "MEDIUM", confidence=0.85,
                            ))
                            idx += 1

    # ── package.json checks ──────────────────────────────────────────────────
    pkg_file = repo / "package.json"
    if pkg_file.exists():
        import json as _json
        try:
            pkg_data = _json.loads(pkg_file.read_text(errors="ignore"))
            deps = {**pkg_data.get("dependencies", {}), **pkg_data.get("devDependencies", {})}
            RISKY_JS_PKGS = {
                "lodash": "lodash has had prototype-pollution vulnerabilities. "
                          "Consider lodash-es or native ES2020+ alternatives.",
                "moment": "moment.js is in maintenance mode. Migrate to date-fns or dayjs.",
                "node-serialize": "node-serialize is known to allow remote code execution. Remove immediately.",
            }
            for pkg_name, note in RISKY_JS_PKGS.items():
                if pkg_name in deps:
                    key = f"dep:{pkg_name}"
                    if key not in seen:
                        seen.add(key)
                        out.append(finding(
                            f"S{idx}", "dependency", "MEDIUM",
                            f"Dependency requires review: {pkg_name}",
                            pkg_file, None,
                            f"{pkg_name}@{deps[pkg_name]}: {note}",
                            f"Review {pkg_name} usage and consider an alternative.",
                            20, "MEDIUM", confidence=0.8,
                        ))
                        idx += 1
        except Exception:
            pass

    return out


# ─── Agent 3: Tests & Documentation ───────────────────────────────────────────

def scan_tests_docs(repo):
    """
    Tests & Documentation Agent.
    Detects: missing tests, coverage gaps, missing README, missing docstrings.
    Distinguishes 'no tests at all' from 'partial test coverage'.
    """
    out = []
    idx = 1
    seen = set()

    source_files = [
        p for p in repo.rglob("*")
        if p.is_file()
        and p.suffix in CODE_EXTS
        and not any(x in p.parts for x in IGNORED)
        and "test" not in p.name.lower()
    ]
    test_files = [
        p for p in repo.rglob("*")
        if p.is_file()
        and ("test" in p.name.lower() or "tests" in str(p).lower())
        and p.suffix in CODE_EXTS
    ]

    # No tests at all
    if source_files and not test_files:
        out.append(finding(
            f"T{idx}", "testing", "HIGH", "No test files detected",
            repo, None,
            f"{len(source_files)} source file(s) detected but no test files found. "
            f"Source files: {', '.join(_rel(repo, p) for p in source_files[:5])}",
            "Add unit tests for critical business logic, error paths, and edge cases. "
            "Start with the highest-complexity modules.",
            120, "MEDIUM", confidence=1.0,
        ))
        idx += 1
    elif source_files and test_files:
        # Partial coverage: identify source files with no corresponding test file
        tested_modules = set()
        for tf in test_files:
            name = tf.stem.replace("test_", "").replace("_test", "")
            tested_modules.add(name)

        untested = [
            p for p in source_files
            if p.stem not in tested_modules
            and p.stem not in ("__init__", "config", "settings", "app", "main", "wsgi", "asgi")
        ]
        for p in untested[:5]:  # Cap at 5 to avoid noise
            rel = _rel(repo, p)
            key = f"notested:{rel}"
            if key not in seen:
                seen.add(key)
                out.append(finding(
                    f"T{idx}", "testing", "HIGH", "Module missing test coverage",
                    p, None,
                    f"{rel} has no corresponding test file. "
                    f"Business-critical modules without tests are a maintenance risk.",
                    f"Create tests/{p.stem}_test.py or tests/test_{p.stem}.py covering "
                    f"the main functions and error paths.",
                    90, "MEDIUM", confidence=0.8,
                ))
                idx += 1

    # README check
    readme = repo / "README.md"
    if not readme.exists():
        out.append(finding(
            f"T{idx}", "documentation", "MEDIUM", "Missing README",
            repo, None,
            "Repository has no README.md. Contributors and reviewers cannot understand the project.",
            "Add a README.md with: project overview, setup instructions, test commands, "
            "architecture notes, and maintenance guidelines.",
            45, "LOW", confidence=1.0,
        ))
        idx += 1
    else:
        # Weak README check
        readme_text = readme.read_text(errors="ignore")
        if len(readme_text.strip()) < 150:
            out.append(finding(
                f"T{idx}", "documentation", "LOW", "README is too brief",
                readme, 1,
                f"README.md exists but contains only {len(readme_text.strip())} characters. "
                "Minimal documentation leaves maintainers without critical context.",
                "Expand to include: setup instructions, test commands, "
                "architecture overview, and dependency notes.",
                30, "LOW", confidence=0.8,
            ))
            idx += 1

    # Missing docstrings on public Python functions
    for p, text in iter_source(repo, {".py"}):
        rel = _rel(repo, p)
        if "test" in rel.lower():
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if node.name.startswith("_"):
                continue  # Skip private functions
            has_doc = (
                node.body
                and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)
            )
            if not has_doc:
                key = f"nodoc:{rel}:{node.name}"
                if key not in seen:
                    seen.add(key)
                    out.append(finding(
                        f"T{idx}", "documentation", "LOW", "Public function missing docstring",
                        p, node.lineno,
                        f"Function '{node.name}' at line {node.lineno} in {rel} "
                        f"has no docstring. Public functions should document purpose, "
                        f"parameters, and return values.",
                        f"Add a docstring to '{node.name}' describing its purpose, "
                        f"parameters, return value, and any raised exceptions.",
                        10, "LOW", confidence=0.9,
                    ))
                    idx += 1

    return out
