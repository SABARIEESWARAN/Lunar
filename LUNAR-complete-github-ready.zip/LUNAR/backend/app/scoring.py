"""
LUNAR Technical Debt Analyst
=============================
Agent 4: Consolidates findings from Code Intelligence, Security, and Tests/Docs agents.

Priority formula:
  priority_score = severity_weight × risk_weight × confidence × impact_weight

Weights are LUNAR-specific and intended for relative ordering only.
Do not present these as industry-standard scores.

Health score: 100 minus a debt_index derived from weighted finding density.
The index is capped at 100 (worst possible health = 0).
"""

SEVERITY_WEIGHT = {"CRITICAL": 10, "HIGH": 6, "MEDIUM": 3, "LOW": 1}
RISK_WEIGHT = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}

# Category impact on the codebase (relative to other categories)
CATEGORY_IMPACT = {
    "security": 3,
    "complexity": 2,
    "maintainability": 2,
    "duplication": 2,
    "testing": 2,
    "dependency": 2,
    "maintenance": 1,
    "documentation": 1,
}


def _priority_score(f: dict) -> float:
    """
    LUNAR priority score (not an industry standard).
    Higher = more urgent to address.
    """
    sev = SEVERITY_WEIGHT.get(f.get("severity", "LOW"), 1)
    risk = RISK_WEIGHT.get(f.get("risk", "LOW"), 1)
    conf = float(f.get("confidence", 0.8))
    impact = CATEGORY_IMPACT.get(f.get("category", "maintenance"), 1)
    return sev * risk * conf * impact


def _generate_recommendation(f: dict, repairable: bool) -> dict:
    """
    Generate a structured AI recommendation for a finding.
    Keeps recommendations factually grounded in the finding evidence.
    """
    category = f.get("category", "")
    severity = f.get("severity", "LOW")
    title = f.get("title", "")
    evidence = f.get("evidence", "")
    recommendation_text = f.get("recommendation", "")
    effort_min = f.get("estimated_effort_min", 30)
    risk = f.get("risk", "MEDIUM")

    what_is_wrong = _what_is_wrong(category, title, evidence)
    why_it_matters = _why_it_matters(category, severity)
    verification_required = _verification_required(category, severity)

    return {
        "what_is_wrong": what_is_wrong,
        "why_it_matters": why_it_matters,
        "recommended_action": recommendation_text,
        "estimated_effort": f"{effort_min} min" if effort_min < 60 else f"{round(effort_min/60, 1)} h",
        "risk_level": risk,
        "lunar_can_automate": repairable,
        "verification_required": verification_required,
    }


def _what_is_wrong(category: str, title: str, evidence: str) -> str:
    if category == "security":
        return f"Security issue detected: {title}. Evidence: {evidence[:200]}"
    if category == "complexity":
        return f"Code complexity issue: {title}. {evidence[:200]}"
    if category == "duplication":
        return f"Duplicated code detected: {evidence[:200]}"
    if category == "maintainability":
        return f"Maintainability problem: {title}. {evidence[:200]}"
    if category == "testing":
        return f"Test coverage gap: {evidence[:200]}"
    if category == "documentation":
        return f"Documentation gap: {title}. {evidence[:200]}"
    if category == "dependency":
        return f"Dependency concern: {evidence[:200]}"
    return f"{title}: {evidence[:200]}"


def _why_it_matters(category: str, severity: str) -> str:
    matters = {
        ("security", "CRITICAL"): (
            "Critical security vulnerabilities can be exploited immediately. "
            "Exposed credentials or unsafe execution patterns put the entire system at risk."
        ),
        ("security", "HIGH"): (
            "Hard-coded credentials or unsafe patterns create a direct attack surface. "
            "If the source code is ever leaked, these become immediately exploitable."
        ),
        ("complexity", "HIGH"): (
            "High-complexity functions have statistically higher bug rates, are harder to test, "
            "and slow down every future change. Each added feature increases the risk of regression."
        ),
        ("duplication", "MEDIUM"): (
            "Duplicated logic means bugs must be fixed in multiple places. "
            "When requirements change, one copy is typically forgotten, causing silent divergence."
        ),
        ("maintainability", "MEDIUM"): (
            "Silent error handlers hide failures. When something goes wrong in production, "
            "there will be no diagnostic information to help diagnose the issue."
        ),
        ("testing", "HIGH"): (
            "Untested business logic is a regression risk with every change. "
            "Without tests, refactoring is dangerous and confident deployment is impossible."
        ),
        ("dependency", "MEDIUM"): (
            "Outdated dependencies may contain known security vulnerabilities "
            "and are no longer receiving patches from maintainers."
        ),
        ("documentation", "MEDIUM"): (
            "Missing documentation increases onboarding time and the probability of "
            "incorrect usage of the module's API."
        ),
        ("maintenance", "LOW"): (
            "Unresolved TODO/FIXME markers indicate known issues that have been deferred. "
            "They accumulate into invisible technical debt."
        ),
    }
    key = (category, severity)
    return matters.get(key, matters.get((category, "MEDIUM"),
        f"This {severity.lower()} {category} issue contributes to technical debt and should be addressed."))


def _verification_required(category: str, severity: str) -> str:
    if category == "security":
        return "Re-run security scanner after repair. Confirm no credentials remain in source."
    if category == "complexity":
        return "All existing tests must pass after refactoring. Add tests if not present."
    if category == "duplication":
        return "Run tests to confirm behaviour is identical after extracting shared logic."
    if category == "testing":
        return "Verify new tests pass and cover the identified gap."
    if severity in ("CRITICAL", "HIGH"):
        return "Run full test suite and static analysis after repair."
    return "Review the change and run relevant tests."


def consolidate(findings: list, stats: dict, elapsed: float, agent_timings: dict = None) -> dict:
    """
    Technical Debt Analyst: consolidate, score, rank, and annotate findings.

    Returns the full LUNAR analysis result including:
    - health_score (0–100, higher is healthier)
    - technical_debt estimate
    - prioritized findings with recommendations
    - agent statuses
    """
    REPAIRABLE_CATEGORIES = {"maintenance", "documentation", "security"}

    # ── Score and rank findings ───────────────────────────────────────────────
    scored = []
    for f in findings:
        repairable = f.get("category", "") in REPAIRABLE_CATEGORIES
        score = _priority_score(f)
        rec = _generate_recommendation(f, repairable)
        scored.append({
            **f,
            "priority_score": round(score, 2),
            "repairable": repairable,
            "ai_recommendation": rec,
        })

    # Sort: primary = priority_score desc, secondary = effort asc (quick wins)
    ranked = sorted(scored, key=lambda x: (x["priority_score"], -x["estimated_effort_min"]), reverse=True)

    # ── Health score calculation ──────────────────────────────────────────────
    raw = sum(_priority_score(f) for f in findings)
    size = max(stats["lines"], 1)
    # Normalise by lines of code density.
    # We use sqrt(size) as a dampener so small repos aren't penalised as harshly.
    # The multiplier 6 is calibrated so a repo with many high-severity findings
    # scores ~30–50 and a clean repo scores 85+.
    import math
    normaliser = max(math.sqrt(size) / 10, 1)
    debt_index = min(100, round((raw / normaliser) * 0.5, 1))
    health = max(0, round(100 - debt_index))

    # ── Effort estimate ───────────────────────────────────────────────────────
    effort_min = sum(f.get("estimated_effort_min", 0) for f in findings)

    # ── Severity and category breakdowns ─────────────────────────────────────
    by_sev = {s: sum(1 for f in findings if f.get("severity") == s) for s in SEVERITY_WEIGHT}
    categories: dict = {}
    for f in findings:
        cat = f.get("category", "other")
        categories[cat] = categories.get(cat, 0) + 1

    # ── Agent timings ─────────────────────────────────────────────────────────
    timings = agent_timings or {}

    return {
        "repository": stats,
        "analysis_seconds": elapsed,
        "health_score": health,
        "technical_debt_minutes": effort_min,
        "technical_debt_hours": round(effort_min / 60, 1),
        "severity_counts": by_sev,
        "category_counts": categories,
        "findings": ranked,
        "total_findings": len(ranked),
        "agent_status": {
            "code_intelligence": {
                "status": "completed",
                "findings": sum(1 for f in findings if f.get("id", "").startswith("C")),
                "elapsed_ms": timings.get("code_intelligence", 0),
            },
            "security_dependencies": {
                "status": "completed",
                "findings": sum(1 for f in findings if f.get("id", "").startswith("S")),
                "elapsed_ms": timings.get("security_dependencies", 0),
            },
            "test_documentation": {
                "status": "completed",
                "findings": sum(1 for f in findings if f.get("id", "").startswith("T")),
                "elapsed_ms": timings.get("test_documentation", 0),
            },
            "debt_analyst": {
                "status": "completed",
                "findings": len(ranked),
                "elapsed_ms": timings.get("debt_analyst", 0),
            },
            "repair": {
                "status": "waiting_for_approval",
                "findings": 0,
                "elapsed_ms": 0,
            },
            "verification": {
                "status": "waiting_for_approval",
                "findings": 0,
                "elapsed_ms": 0,
            },
        },
        "priority_summary": _build_priority_summary(ranked),
    }


def _build_priority_summary(ranked: list) -> dict:
    """Top 3 highest-priority findings as a quick summary."""
    top = ranked[:3]
    return {
        "top_findings": [
            {
                "id": f["id"],
                "title": f["title"],
                "severity": f["severity"],
                "category": f["category"],
                "priority_score": f["priority_score"],
            }
            for f in top
        ],
        "immediate_action_required": any(
            f["severity"] == "CRITICAL" for f in ranked
        ),
        "repairable_count": sum(1 for f in ranked if f.get("repairable")),
    }
