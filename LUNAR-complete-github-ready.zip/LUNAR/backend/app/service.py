"""
LUNAR Service Layer
===================
Covers:
  - Async job management (Phases 2–3)
  - Normalized finding model (Phase 4)
  - Repair proposal + workspace management (Phases 3, 5)
  - Diff generation (Phase 6)
  - Approval / rejection (Phase 7)
  - Verification (Phase 8)
  - Before/after metrics (Phase 9)

Safety rules enforced here:
  - Never modify the original cloned workspace.
  - Repairs happen only in an isolated copy of the workspace.
  - A repair is not "verified" until actual checks pass.
"""

import ast
import io
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
import zipfile
import difflib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

import httpx

from .scanners import scan_code, scan_security, scan_tests_docs
from .scoring import consolidate

# ─── In-memory stores (sufficient for hackathon demo) ────────────────────────
_jobs: dict = {}        # job_id  → job dict
_repairs: dict = {}     # repair_id → repair dict

_jobs_lock = threading.Lock()
_repairs_lock = threading.Lock()

IGNORED = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build"}

# ─── Finding normalisation ────────────────────────────────────────────────────

def _normalise_findings(raw: list, repo_path: Path = None) -> list:
    """
    Convert scored findings (already processed by consolidate()) to the
    canonical LUNAR frontend schema.

    The consolidate() function in scoring.py already adds:
      - priority_score, repairable, ai_recommendation

    This function:
      - lowercases severity for frontend display consistency
      - computes a clean relative file path
      - keeps all other fields from consolidate() intact
    """
    out = []
    for f in raw:
        path_str = f.get("path", "")
        # Compute clean relative path if we have the repo root
        if repo_path and path_str:
            try:
                rel = str(Path(path_str).relative_to(repo_path)).replace("\\", "/")
            except ValueError:
                rel = path_str.replace("\\", "/")
        else:
            rel = path_str.replace("\\", "/")

        out.append({
            "id": f.get("id", ""),
            "severity": f.get("severity", "LOW").lower(),
            "category": f.get("category", "maintainability"),
            "title": f.get("title", ""),
            "file": rel,
            "line": f.get("line"),
            "evidence": f.get("evidence", ""),
            "recommendation": f.get("recommendation", ""),
            "estimated_effort_min": f.get("estimated_effort_min", 30),
            "risk": f.get("risk", "MEDIUM"),
            "confidence": f.get("confidence", 0.8),
            "repairable": f.get("repairable", False),
            "priority_score": f.get("priority_score", 0.0),
            "ai_recommendation": f.get("ai_recommendation", {}),
        })
    return out


# ─── Workspace helpers ────────────────────────────────────────────────────────

def _github_url_to_zip(url: str):
    """
    Given a GitHub repository URL, return the zip archive URL and the repo slug.
    Supports:
      https://github.com/owner/repo
      https://github.com/owner/repo.git
      https://github.com/owner/repo/tree/branchname
    """
    import re as _re
    url = url.rstrip("/").removesuffix(".git")
    m = _re.match(r"https?://github\.com/([^/]+/[^/]+?)(?:/tree/([^/]+))?$", url)
    if m:
        slug = m.group(1)
        branch = m.group(2) or "HEAD"
        zip_url = f"https://github.com/{slug}/archive/refs/heads/{branch}.zip"
        return zip_url, slug, branch
    # Fallback: treat last two path segments as owner/repo
    parts = [p for p in url.rstrip("/").split("/") if p]
    if len(parts) >= 2:
        slug = "/".join(parts[-2:])
        zip_url = f"https://github.com/{slug}/archive/refs/heads/main.zip"
        return zip_url, slug, "main"
    raise ValueError(f"Cannot parse GitHub URL: {url}")


def _fetch_repo(url: str, work_root: Path) -> Path:
    """
    Download a GitHub repository as a ZIP archive and extract it.
    Falls back to git clone if git is available.
    Supports file:// local paths for demo/testing.
    Returns the path to the extracted repo root.
    """
    # Built-in synthetic hospital demo. This keeps the hackathon demo self-contained.
    if url.strip().lower() in {"demo://hospital", "lunar://hospital-demo"}:
        demo = Path(__file__).resolve().parents[2] / "demo-repo"
        if not demo.is_dir():
            raise ValueError(f"Bundled demo repository not found: {demo}")
        dest = work_root / "repo"
        shutil.copytree(str(demo), str(dest))
        return dest

    # Local path support for demo testing: file:///absolute/path
    if url.startswith("file://"):
        # Strip file:// or file:/// prefix (handles Windows paths like file:///C:/...)
        raw = url[7:]  # remove "file://"
        if raw.startswith("/") and len(raw) > 2 and raw[2] == ":":
            raw = raw[1:]  # Windows: /C:/path → C:/path
        local_path = Path(raw)
        if local_path.is_dir():
            dest = work_root / "repo"
            shutil.copytree(str(local_path), str(dest))
            return dest
        raise ValueError(f"Local path not found: {local_path}")

    # Try git clone first
    git_exe = shutil.which("git")
    if git_exe:
        repo = work_root / "repo"
        subprocess.run(
            [git_exe, "clone", "--depth", "1", url, str(repo)],
            check=True, capture_output=True, text=True,
        )
        return repo

    # No git — use GitHub ZIP download
    zip_url, slug, branch = _github_url_to_zip(url)
    zip_data = _download_zip(zip_url)
    if zip_data is None:
        # Branch might be "master" — try that
        alt_url = zip_url.replace("/main.zip", "/master.zip").replace("/HEAD.zip", "/master.zip")
        zip_data = _download_zip(alt_url)
    if zip_data is None:
        raise RuntimeError(f"Could not download repository archive from {zip_url}")

    zip_dir = work_root / "zip_extract"
    zip_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
        zf.extractall(str(zip_dir))

    # GitHub ZIP archives have a single top-level directory like "repo-main/"
    children = [c for c in zip_dir.iterdir() if c.is_dir()]
    if len(children) == 1:
        return children[0]
    return zip_dir


def _download_zip(url: str) -> Optional[bytes]:
    try:
        with httpx.Client(follow_redirects=True, timeout=60) as client:
            r = client.get(url)
            if r.status_code == 200:
                return r.content
            return None
    except Exception:
        return None


def _repo_stats(repo: Path) -> dict:
    files = []
    lines = 0
    languages: dict = {}
    for p in repo.rglob("*"):
        if not p.is_file() or any(part in IGNORED for part in p.parts):
            continue
        files.append(p)
        try:
            text = p.read_text(errors="ignore")
            lines += len(text.splitlines())
        except Exception:
            continue
        ext = p.suffix.lower()
        lang = {
            ".py": "Python", ".js": "JavaScript", ".jsx": "JavaScript",
            ".ts": "TypeScript", ".tsx": "TypeScript",
        }.get(ext)
        if lang:
            languages[lang] = languages.get(lang, 0) + 1
    return {"files": len(files), "lines": lines, "languages": languages}


def _cleanup_job_workspace(job: dict):
    """Remove both original and repair workspaces for a completed/failed job."""
    try:
        orig = job.get("_workspace_root")
        if orig and Path(orig).exists():
            shutil.rmtree(orig, ignore_errors=True)
    except Exception:
        pass


# ─── Phase 2: Async Analysis Job ─────────────────────────────────────────────

def start_analysis_job(url: str) -> dict:
    """Submit an analysis job and return immediately with a job_id."""
    job_id = str(uuid.uuid4())
    job = {
        "job_id": job_id,
        "status": "queued",
        "progress": 0,
        "stage": "queued",
        "repo_url": url,
        "result": None,
        "error": None,
        "_workspace_root": None,   # internal: root of temp dir
        "_repo_path": None,        # internal: path to cloned repo
    }
    with _jobs_lock:
        _jobs[job_id] = job

    t = threading.Thread(target=_run_analysis, args=(job_id,), daemon=True)
    t.start()
    return {"job_id": job_id, "status": "queued"}


def get_job_status(job_id: str) -> Optional[dict]:
    with _jobs_lock:
        job = _jobs.get(job_id)
    if job is None:
        return None
    # Return safe public view (strip internal keys)
    return _public_job(job)


def _public_job(job: dict) -> dict:
    return {
        "job_id": job["job_id"],
        "status": job["status"],
        "progress": job["progress"],
        "stage": job["stage"],
        "repo_url": job["repo_url"],
        "result": job["result"],
        "error": job["error"],
    }


def _set_job(job_id: str, **kwargs):
    with _jobs_lock:
        if job_id in _jobs:
            _jobs[job_id].update(kwargs)


def _run_analysis(job_id: str):
    """Background thread: clone → scan (parallel) → score → store."""
    try:
        _set_job(job_id, status="running", progress=5, stage="cloning")

        with _jobs_lock:
            url = _jobs[job_id]["repo_url"]

        # Fetch repo (git clone or ZIP download)
        work_root = Path(tempfile.mkdtemp(prefix="lunar-"))
        repo = _fetch_repo(url, work_root)
        _set_job(job_id, progress=20, stage="scanning", _workspace_root=str(work_root), _repo_path=str(repo))

        started = time.time()
        stats = _repo_stats(repo)

        # Parallel scan — 3 independent agents with per-agent timing
        agent_start_times: dict = {}
        agent_timings: dict = {}

        with ThreadPoolExecutor(max_workers=3) as pool:
            agent_futures = {
                pool.submit(scan_code, repo): "code_intelligence",
                pool.submit(scan_security, repo): "security_dependencies",
                pool.submit(scan_tests_docs, repo): "test_documentation",
            }
            # Record start time per future
            for future in agent_futures:
                agent_start_times[id(future)] = time.time()

            raw_findings = []
            completed_agents = 0
            for future in as_completed(agent_futures):
                agent_name = agent_futures[future]
                elapsed_ms = round((time.time() - started) * 1000)
                agent_timings[agent_name] = elapsed_ms
                raw_findings.extend(future.result())
                completed_agents += 1
                progress = 20 + (completed_agents * 20)  # 40 → 60 → 80
                _set_job(job_id, progress=progress, stage=f"agent_{agent_name}_completed")

        _set_job(job_id, progress=85, stage="consolidating")
        debt_start = time.time()
        elapsed = round(time.time() - started, 2)

        # Technical Debt Analyst: consolidate + score + rank + recommend
        agent_timings["debt_analyst"] = round((time.time() - debt_start) * 1000)
        result = consolidate(raw_findings, stats, elapsed, agent_timings=agent_timings)

        # Normalise findings: compute clean relative paths, lowercase severity
        result["findings"] = _normalise_findings(result["findings"], repo_path=repo)
        result["total_findings"] = len(result["findings"])

        # Store workspace path in job for later repair use
        _set_job(
            job_id,
            status="completed",
            progress=100,
            stage="completed",
            result=result,
            _workspace_root=str(work_root),
            _repo_path=str(repo),
        )

    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr or ""
        _set_job(job_id, status="failed", progress=0, stage="failed",
                 error=f"Clone failed: {stderr[:300]}")
    except Exception as exc:
        _set_job(job_id, status="failed", progress=0, stage="failed",
                 error=str(exc))


# ─── Phase 5: Repair Proposal ─────────────────────────────────────────────────

# Repair strategies keyed on finding category + simple heuristic
# These are the ONLY auto-repairable types for Phase 5.

def _repair_todo_marker(repo_path: Path, finding: dict) -> Optional[dict]:
    """
    Remove or annotate a TODO/FIXME/HACK marker.
    Conservative: we add a tracked comment rather than deleting code.
    """
    file_rel = finding["file"]
    # finding["file"] may be an absolute path from the scanner
    file_path = Path(file_rel)
    if not file_path.is_absolute():
        file_path = repo_path / file_rel
    if not file_path.exists():
        return None

    text = file_path.read_text(errors="ignore")
    # Replace the first matching TODO/FIXME/HACK with a tracked comment
    new_text, count = re.subn(
        r"\b(TODO|FIXME|HACK)\b",
        r"# TRACKED-ISSUE(\1):",
        text,
        count=1,
        flags=re.IGNORECASE,
    )
    if count == 0:
        return None

    rel = _make_relative(repo_path, file_path)
    short_rel = rel.replace("\\", "/")
    return {
        "file": short_rel,
        "original": text,
        "patched": new_text,
        "description": f"Converted maintenance marker to tracked comment in {short_rel}",
    }


def _repair_missing_docstring(repo_path: Path, finding: dict) -> Optional[dict]:
    """Add a concise docstring to a public Python function missing one.

    This is intentionally conservative: only the first public function in the
    target file is modified, and only when the scanner's evidence identifies
    the function line.
    """
    file_rel = finding.get("file", "")
    file_path = Path(file_rel)
    if not file_path.is_absolute():
        file_path = repo_path / file_rel
    if not file_path.exists() or file_path.suffix != ".py":
        return None

    text = file_path.read_text(errors="ignore")
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return None

    target_line = finding.get("line")
    candidates = [
        n for n in tree.body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        and not n.name.startswith("_")
        and (target_line is None or n.lineno == target_line)
    ]
    if not candidates:
        candidates = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and not n.name.startswith("_")]
    if not candidates:
        return None

    fn = candidates[0]
    if ast.get_docstring(fn) is not None:
        return None

    lines = text.splitlines(keepends=True)
    insert_at = fn.body[0].lineno - 1 if fn.body else fn.lineno
    indent = " " * (len(lines[fn.lineno - 1]) - len(lines[fn.lineno - 1].lstrip())) + "    "
    doc = f'{indent}"""LUNAR: document the public {fn.name} operation."""\n'
    new_lines = lines[:insert_at] + [doc] + lines[insert_at:]
    new_text = "".join(new_lines)
    rel = _make_relative(repo_path, file_path).replace("\\", "/")
    return {
        "file": rel,
        "original": text,
        "patched": new_text,
        "description": f"Added a concise docstring to public function {fn.name} in {rel}",
    }


def _repair_missing_readme(repo_path: Path, finding: dict) -> Optional[dict]:
    """Generate a minimal README.md stub."""
    readme_path = repo_path / "README.md"
    if readme_path.exists():
        return None

    stub = "# Project\n\nThis project requires documentation.\n\n## Setup\n\nAdd setup instructions here.\n\n## Tests\n\nAdd test instructions here.\n"
    return {
        "file": "README.md",
        "original": "",
        "patched": stub,
        "description": "Added minimal README.md stub",
    }


def _repair_hardcoded_credential(repo_path: Path, finding: dict) -> Optional[dict]:
    """
    Replace a hard-coded credential value with an environment-variable lookup.
    Only handles the simple `key = "value"` pattern found by the security scanner.
    """
    file_rel = finding["file"]
    file_path = Path(file_rel)
    if not file_path.is_absolute():
        file_path = repo_path / file_rel
    if not file_path.exists():
        return None

    text = file_path.read_text(errors="ignore")
    # Match: password/secret/api_key = "literal"  (Python assignment)
    pattern = r'(?i)((password|passwd|secret|api[_-]?key)\s*=\s*)["\'][^"\']+["\']'
    match = re.search(pattern, text)
    if not match:
        return None

    key_name = match.group(2).upper().replace("-", "_")
    env_var = f"APP_{key_name}"
    replacement = f"{match.group(1)}os.environ.get('{env_var}', '')"
    new_text = text[:match.start()] + replacement + text[match.end():]

    # Ensure os is imported
    if "import os" not in new_text:
        new_text = "import os\n" + new_text

    rel = _make_relative(repo_path, file_path)
    short_rel = rel.replace("\\", "/")
    return {
        "file": short_rel,
        "original": text,
        "patched": new_text,
        "description": f"Replaced hard-coded credential with os.environ.get('{env_var}', '') in {short_rel}",
    }


def _make_relative(base: Path, target: Path) -> str:
    try:
        return str(target.relative_to(base))
    except ValueError:
        return str(target)


_REPAIR_STRATEGIES = {
    "maintenance": _repair_todo_marker,
    "documentation": _repair_missing_docstring,
    "security": _repair_hardcoded_credential,
}


def propose_repair(job_id: str, finding_id: str) -> dict:
    with _jobs_lock:
        job = _jobs.get(job_id)
    if job is None:
        raise ValueError(f"Job {job_id} not found")
    if job["status"] != "completed":
        raise ValueError(f"Job {job_id} is not completed (status: {job['status']})")

    # Find the finding
    findings = job["result"]["findings"]
    finding = next((f for f in findings if f["id"] == finding_id), None)
    if finding is None:
        raise ValueError(f"Finding {finding_id} not found in job {job_id}")

    repo_path_str = job.get("_repo_path")
    if not repo_path_str:
        raise ValueError("Workspace not available for this job")
    repo_path = Path(repo_path_str)

    # Create an isolated repair copy of the workspace
    repair_id = str(uuid.uuid4())
    repair_root = Path(tempfile.mkdtemp(prefix="lunar-repair-"))
    repair_repo = repair_root / "repo"
    shutil.copytree(str(repo_path), str(repair_repo))

    # Select repair strategy
    category = finding.get("category", "")
    strategy = _REPAIR_STRATEGIES.get(category)

    if strategy is None:
        # Not auto-repairable
        shutil.rmtree(repair_root, ignore_errors=True)
        return {
            "repair_id": None,
            "status": "manual_review_required",
            "finding_id": finding_id,
            "reason": f"Category '{category}' does not have an automatic repair strategy. Manual review required.",
        }

    # Translate the finding's file path from original workspace to repair workspace
    finding_for_repair = dict(finding)
    orig_file = finding.get("file", "")
    if orig_file and Path(orig_file).is_absolute():
        orig_path = Path(orig_file)
        try:
            rel_in_orig = orig_path.relative_to(repo_path)
            finding_for_repair["file"] = str(repair_repo / rel_in_orig)
        except ValueError:
            pass  # not under repo_path; leave as-is

    patch = strategy(repair_repo, finding_for_repair)

    if patch is None:
        shutil.rmtree(repair_root, ignore_errors=True)
        return {
            "repair_id": None,
            "status": "manual_review_required",
            "finding_id": finding_id,
            "reason": "Could not locate the specific code pattern to repair automatically.",
        }

    # Write the patched file into the repair workspace
    # patch["file"] is relative (e.g. "examples/tutorial/tests/conftest.py")
    patched_file_path = repair_repo / Path(patch["file"])
    patched_file_path.parent.mkdir(parents=True, exist_ok=True)
    patched_file_path.write_text(patch["patched"], encoding="utf-8")

    repair = {
        "repair_id": repair_id,
        "job_id": job_id,
        "finding_id": finding_id,
        "finding": finding,
        "status": "proposed",          # proposed → approved / rejected → verified
        "description": patch["description"],
        "risk": finding.get("risk", "MEDIUM"),
        "file": patch["file"],
        "_original_text": patch["original"],
        "_patched_text": patch["patched"],
        "_repair_repo": str(repair_repo),
        "_repair_root": str(repair_root),
        "_orig_repo": str(repo_path),
        "verification_result": None,
    }

    with _repairs_lock:
        _repairs[repair_id] = repair

    return {
        "repair_id": repair_id,
        "status": "proposed",
        "finding_id": finding_id,
        "description": patch["description"],
        "risk": finding.get("risk", "MEDIUM"),
        "file": patch["file"],
    }


# ─── Phase 6: Diff ────────────────────────────────────────────────────────────

def get_diff(repair_id: str) -> Optional[dict]:
    with _repairs_lock:
        repair = _repairs.get(repair_id)
    if repair is None:
        return None

    original = repair.get("_original_text", "")
    patched = repair.get("_patched_text", "")
    file_name = repair.get("file", "unknown")

    diff_lines = list(difflib.unified_diff(
        original.splitlines(keepends=True),
        patched.splitlines(keepends=True),
        fromfile=f"a/{file_name}",
        tofile=f"b/{file_name}",
        lineterm="",
    ))
    unified_diff = "".join(diff_lines)

    return {
        "repair_id": repair_id,
        "status": repair["status"],
        "file": file_name,
        "diff": unified_diff,
        "description": repair.get("description", ""),
        "risk": repair.get("risk", "MEDIUM"),
    }


# ─── Phase 7: Approval / Rejection ───────────────────────────────────────────

def approve_repair(repair_id: str) -> Optional[dict]:
    with _repairs_lock:
        repair = _repairs.get(repair_id)
    if repair is None:
        return None
    if repair["status"] not in ("proposed",):
        return {"repair_id": repair_id, "status": repair["status"],
                "message": f"Cannot approve repair in status '{repair['status']}'"}
    repair["status"] = "approved"
    return {"repair_id": repair_id, "status": "approved",
            "message": "Repair approved. Run /api/verify/{repair_id} to verify."}


def reject_repair(repair_id: str) -> Optional[dict]:
    with _repairs_lock:
        repair = _repairs.get(repair_id)
    if repair is None:
        return None
    repair["status"] = "rejected"
    # Clean up repair workspace
    repair_root = repair.get("_repair_root")
    if repair_root:
        shutil.rmtree(repair_root, ignore_errors=True)
    return {"repair_id": repair_id, "status": "rejected",
            "message": "Repair rejected. Workspace cleaned up."}


# ─── Phase 8 & 9: Verification + Before/After Metrics ────────────────────────

def run_verification(repair_id: str) -> dict:
    with _repairs_lock:
        repair = _repairs.get(repair_id)
    if repair is None:
        raise ValueError(f"Repair {repair_id} not found")
    if repair["status"] != "approved":
        raise ValueError(
            f"Repair must be approved before verification (current status: {repair['status']})"
        )

    repair_repo = Path(repair["_repair_repo"])
    orig_repo = Path(repair["_orig_repo"])

    checks = []

    # ── 1. Syntax / static check (delta-based: only fail if repair introduced new errors) ─
    lang = _detect_language(repair_repo)
    orig_static = _run_static_checks(orig_repo, lang)
    repair_static = _run_static_checks(repair_repo, lang)
    checks.extend(_compare_static_checks(orig_static, repair_static))

    # ── 2. Test runner ────────────────────────────────────────────────────────
    checks.extend(_run_tests(repair_repo, lang))

    # ── 3. Before/after metrics ───────────────────────────────────────────────
    before_metrics = _compute_metrics(orig_repo)
    after_metrics = _compute_metrics(repair_repo)

    # ── Determine overall status ──────────────────────────────────────────────
    # Only count checks that explicitly failed (not skipped); test runner failures do count
    hard_failures = [c for c in checks if c["status"] == "failed" and "regression" in c.get("name", "")]
    test_failures = [c for c in checks if c["status"] == "failed" and c.get("check_type") == "test"]
    regressions = _find_regressions(before_metrics, after_metrics)
    any_failure = hard_failures or test_failures
    status = "failed" if any_failure else ("partial" if regressions else "passed")

    verification_result = {
        "repair_id": repair_id,
        "status": status,
        "checks": checks,
        "regressions": regressions,
        "before_metrics": before_metrics,
        "after_metrics": after_metrics,
        "improvement": _delta(before_metrics, after_metrics),
        "summary": _verification_summary(status, checks, before_metrics, after_metrics),
    }

    with _repairs_lock:
        _repairs[repair_id]["status"] = "verified" if status == "passed" else "verification_failed"
        _repairs[repair_id]["verification_result"] = verification_result

    return verification_result


def _compare_static_checks(orig_checks: list, repair_checks: list) -> list:
    """
    Compare static check results between original and repaired workspaces.
    If the repair introduced new errors (higher error count), mark as 'regression'.
    If error count is equal or improved, mark as 'passed'.
    If the checker was unavailable in both, mark as 'skipped'.
    """
    results = []
    for orig, rep in zip(orig_checks, repair_checks):
        orig_exit = orig.get("exit_code")
        rep_exit = rep.get("exit_code")

        if orig_exit is None and rep_exit is None:
            results.append({**rep, "status": "skipped", "name": rep["name"],
                             "note": "Checker not available"})
            continue

        # Count error lines as a rough proxy for error count
        orig_errors = orig["output"].count("\n") if orig.get("output") else 0
        rep_errors = rep["output"].count("\n") if rep.get("output") else 0

        if rep_errors > orig_errors + 2:
            # Repair introduced meaningfully more errors
            status = "failed"
            name = f"regression: {rep['name']}"
        else:
            status = "passed"
            name = rep["name"]

        results.append({
            **rep,
            "status": status,
            "name": name,
            "check_type": "static",
            "before_errors": orig_errors,
            "after_errors": rep_errors,
            "output": f"Before: {orig_errors} issues\nAfter: {rep_errors} issues\n\n" + rep.get("output", "")[:600],
        })
    return results


def _detect_language(repo: Path) -> str:
    """Return the primary language of the repository."""
    py_files = list(repo.rglob("*.py"))
    js_files = list(repo.rglob("*.js")) + list(repo.rglob("*.jsx")) + list(repo.rglob("*.ts"))
    if len(py_files) >= len(js_files):
        return "python"
    return "javascript"


def _python_exe() -> str:
    """Return the current Python executable path."""
    import sys
    return sys.executable


def _run_static_checks(repo: Path, lang: str) -> list:
    checks = []
    pyexe = _python_exe()

    if lang == "python":
        # Try pyflakes (lightweight), then compile every Python source file.
        py_files = [str(f) for f in repo.rglob("*.py") if not any(x in f.parts for x in IGNORED)]
        compile_cmd = [pyexe, "-m", "py_compile", *py_files] if py_files else None
        checkers = [[pyexe, "-m", "pyflakes", "."]]
        if compile_cmd:
            checkers.append(compile_cmd)
        for checker in checkers:
            try:
                result = subprocess.run(
                    checker, cwd=str(repo),
                    capture_output=True, text=True, timeout=30,
                )
                checks.append({
                    "name": " ".join(checker[1:3]),  # e.g. "-m pyflakes"
                    "command": " ".join(checker),
                    "status": "passed" if result.returncode == 0 else "failed",
                    "exit_code": result.returncode,
                    "output": (result.stdout + result.stderr)[:800],
                })
                break  # Only need one static check
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue

    elif lang == "javascript":
        # Try node syntax check
        js_files = list(repo.rglob("*.js"))[:5]
        for f in js_files:
            try:
                result = subprocess.run(
                    ["node", "--check", str(f)],
                    capture_output=True, text=True, timeout=15,
                )
                checks.append({
                    "name": f"node --check {f.name}",
                    "command": f"node --check {f}",
                    "status": "passed" if result.returncode == 0 else "failed",
                    "exit_code": result.returncode,
                    "output": (result.stdout + result.stderr)[:400],
                })
            except (FileNotFoundError, subprocess.TimeoutExpired):
                break

    if not checks:
        checks.append({
            "name": "static_check",
            "command": "N/A",
            "status": "skipped",
            "exit_code": None,
            "output": "No compatible static checker found in environment.",
        })

    return checks


def _run_tests(repo: Path, lang: str) -> list:
    checks = []
    pyexe = _python_exe()

    if lang == "python":
        # Look for pytest or unittest discover
        has_tests = bool(list(repo.rglob("test_*.py")) + list(repo.rglob("*_test.py")))
        if has_tests:
            for runner in [[pyexe, "-m", "pytest", "--tb=short", "-q"],
                           [pyexe, "-m", "unittest", "discover"]]:
                try:
                    result = subprocess.run(
                        runner, cwd=str(repo),
                        capture_output=True, text=True, timeout=60,
                    )
                    checks.append({
                        "name": " ".join(runner[1:3]),
                        "command": " ".join(runner),
                        "check_type": "test",
                        "status": "passed" if result.returncode == 0 else "failed",
                        "exit_code": result.returncode,
                        "output": (result.stdout + result.stderr)[:1200],
                    })
                    break
                except (FileNotFoundError, subprocess.TimeoutExpired):
                    continue

    elif lang == "javascript":
        pkg = repo / "package.json"
        if pkg.exists():
            try:
                import json
                data = json.loads(pkg.read_text(errors="ignore"))
                if "test" in data.get("scripts", {}):
                    result = subprocess.run(
                        ["npm", "test", "--", "--passWithNoTests"],
                        cwd=str(repo), capture_output=True, text=True, timeout=60,
                    )
                    checks.append({
                        "name": "npm test",
                        "command": "npm test",
                        "check_type": "test",
                        "status": "passed" if result.returncode == 0 else "failed",
                        "exit_code": result.returncode,
                        "output": (result.stdout + result.stderr)[:1200],
                    })
            except Exception:
                pass

    if not checks:
        checks.append({
            "name": "test_runner",
            "command": "N/A",
            "check_type": "test",
            "status": "skipped",
            "exit_code": None,
            "output": "No tests detected or no compatible test runner found.",
        })

    return checks


def _compute_metrics(repo: Path) -> dict:
    """Re-run the full scan on a workspace and return summary metrics."""
    try:
        stats = _repo_stats(repo)
        with ThreadPoolExecutor(max_workers=3) as pool:
            jobs = [
                pool.submit(scan_code, repo),
                pool.submit(scan_security, repo),
                pool.submit(scan_tests_docs, repo),
            ]
            raw = []
            for j in as_completed(jobs):
                raw.extend(j.result())
        result = consolidate(raw, stats, 0)
        return {
            "health_score": result["health_score"],
            "technical_debt_hours": result["technical_debt_hours"],
            "technical_debt_minutes": result["technical_debt_minutes"],
            "total_findings": len(result["findings"]),
            "severity_counts": result["severity_counts"],
        }
    except Exception as exc:
        return {"error": str(exc)}


def _find_regressions(before: dict, after: dict) -> list:
    regressions = []
    if "error" in before or "error" in after:
        return regressions
    if after.get("health_score", 100) < before.get("health_score", 100) - 5:
        regressions.append({
            "type": "health_score_drop",
            "before": before.get("health_score"),
            "after": after.get("health_score"),
            "description": "Health score decreased after repair.",
        })
    after_critical = after.get("severity_counts", {}).get("CRITICAL", 0)
    before_critical = before.get("severity_counts", {}).get("CRITICAL", 0)
    if after_critical > before_critical:
        regressions.append({
            "type": "new_critical_findings",
            "before": before_critical,
            "after": after_critical,
            "description": "New CRITICAL findings introduced by repair.",
        })
    return regressions


def _delta(before: dict, after: dict) -> dict:
    if "error" in before or "error" in after:
        return {}
    return {
        "health_score_delta": after.get("health_score", 0) - before.get("health_score", 0),
        "findings_delta": after.get("total_findings", 0) - before.get("total_findings", 0),
        "debt_hours_delta": round(
            after.get("technical_debt_hours", 0) - before.get("technical_debt_hours", 0), 1
        ),
    }


def _verification_summary(status: str, checks: list, before: dict, after: dict) -> str:
    passed = sum(1 for c in checks if c["status"] == "passed")
    failed = sum(1 for c in checks if c["status"] == "failed")
    skipped = sum(1 for c in checks if c["status"] == "skipped")
    health_delta = after.get("health_score", 0) - before.get("health_score", 0)
    delta_str = f"+{health_delta}" if health_delta >= 0 else str(health_delta)
    return (
        f"Verification {status.upper()}. "
        f"Checks: {passed} passed, {failed} failed, {skipped} skipped. "
        f"Health score: {before.get('health_score','?')} → {after.get('health_score','?')} ({delta_str})."
    )
