"""Integration-style smoke test and optional CLI report for the bundled demo repository."""
from pathlib import Path

from app.scanners import scan_code, scan_security, scan_tests_docs
from app.scoring import consolidate


REPO = Path(__file__).resolve().parents[1] / "demo-repo"


def build_demo_result():
    code_findings = scan_code(REPO)
    security_findings = scan_security(REPO)
    test_findings = scan_tests_docs(REPO)
    all_findings = code_findings + security_findings + test_findings
    all_files = [p for p in REPO.rglob("*") if p.is_file() and "__pycache__" not in p.parts]
    line_count = sum(len(p.read_text(errors="ignore").splitlines()) for p in all_files)
    stats = {
        "files": len(all_files),
        "lines": line_count,
        "languages": {"Python": sum(1 for p in all_files if p.suffix == ".py")},
    }
    return consolidate(all_findings, stats, 0.0)


def test_demo_repository_has_expected_findings():
    result = build_demo_result()
    assert result["total_findings"] >= 1
    assert result["severity_counts"]["HIGH"] >= 1
    assert result["technical_debt_minutes"] > 0


if __name__ == "__main__":
    result = build_demo_result()
    print(f"Findings: {result['total_findings']}")
    print(f"Health score: {result['health_score']}/100")
    print(f"Technical debt estimate: {result['technical_debt_hours']}h")
    for finding in result["findings"][:12]:
        print(
            f"[{finding['severity']}] {finding['id']} {finding['title']} "
            f"score={finding['priority_score']}"
        )
