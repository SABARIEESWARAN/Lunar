from pathlib import Path

from app.scanners import scan_code, scan_security, scan_tests_docs


DEMO_REPO = Path(__file__).resolve().parents[2] / "demo-repo"


def test_demo_repo_produces_code_findings():
    findings = scan_code(DEMO_REPO)
    assert findings
    categories = {finding["category"] for finding in findings}
    assert "complexity" in categories
    assert "maintenance" in categories


def test_demo_repo_produces_security_findings():
    findings = scan_security(DEMO_REPO)
    assert findings
    assert any("credential" in finding["title"].lower() for finding in findings)


def test_demo_repo_produces_test_or_documentation_findings():
    findings = scan_tests_docs(DEMO_REPO)
    assert findings
    categories = {finding["category"] for finding in findings}
    assert "testing" in categories or "documentation" in categories
