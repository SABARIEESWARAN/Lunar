from app.scoring import consolidate


def test_consolidate_prioritizes_high_risk_findings():
    findings = [
        {
            "id": "S1",
            "category": "security",
            "severity": "HIGH",
            "risk": "HIGH",
            "confidence": 0.9,
            "title": "Hard-coded credential",
            "evidence": "password=...",
            "recommendation": "Use environment variables",
            "estimated_effort_min": 20,
        },
        {
            "id": "M1",
            "category": "maintenance",
            "severity": "LOW",
            "risk": "LOW",
            "confidence": 0.9,
            "title": "TODO marker",
            "evidence": "TODO",
            "recommendation": "Track the work",
            "estimated_effort_min": 10,
        },
    ]

    result = consolidate(findings, {"files": 2, "lines": 100}, 0.1)

    assert result["total_findings"] == 2
    assert result["findings"][0]["id"] == "S1"
    assert result["findings"][0]["priority_score"] > result["findings"][1]["priority_score"]
    assert result["technical_debt_minutes"] == 30


def test_health_score_is_bounded():
    result = consolidate([], {"files": 0, "lines": 0}, 0.1)
    assert 0 <= result["health_score"] <= 100
    assert result["technical_debt_minutes"] == 0
