# Security & Dependency Agent

Inspect the repository for:
- hard-coded credentials/secrets
- unsafe dynamic execution
- injection-prone patterns
- insecure configuration
- outdated/deprecated dependencies
- dependency risk
- unsafe API usage

Do not invent vulnerabilities or CVEs. If a dependency needs external advisory verification, mark it as requiring verification rather than claiming a vulnerability.

Every finding needs repository evidence.

Return the standard LUNAR finding schema.
