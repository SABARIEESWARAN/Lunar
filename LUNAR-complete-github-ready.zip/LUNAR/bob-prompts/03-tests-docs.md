# Tests & Documentation Agent

Inspect:
- presence and organization of tests
- missing tests for important business logic
- error-path coverage gaps
- brittle/weak tests
- missing README/setup documentation
- missing API/module documentation
- stale maintenance instructions
- TODO/FIXME documentation debt

Distinguish "no tests detected" from "low coverage" unless coverage evidence exists.

Return the standard LUNAR finding schema.
