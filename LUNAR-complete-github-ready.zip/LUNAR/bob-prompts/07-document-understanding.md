# Document Understanding Agent

When repository documents are present, inspect:
- README
- CONTRIBUTING
- architecture documents
- API specifications
- deployment/setup documentation
- maintenance notes

Extract project conventions and constraints that should influence repair decisions.

Do not treat documentation statements as proof that code is correct. Compare documented intent with implementation evidence.

Return:
{
 "documents":[],
 "project_conventions":[],
 "constraints":[],
 "implementation_mismatches":[]
}
