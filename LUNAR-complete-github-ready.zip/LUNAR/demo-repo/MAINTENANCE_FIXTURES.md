# Demo Maintenance Fixtures

This file documents intentional issues in the synthetic demo repository. It exists so judges can reproduce the expected maintenance workflow.

- `config.py`: hard-coded credential patterns.
- `appointments.py`: large/high-complexity function and maintenance markers.
- `billing.py`: large/high-complexity function and maintenance markers.
- `patients.py`: weak exception handling, maintenance markers, and documentation gaps.
- `staff.py`: maintenance marker and insufficient corresponding tests.
- `notifications.py`: insufficient corresponding tests.
- `requirements.txt`: dependency-version finding exercised by the scanner.

These are synthetic fixtures, not real hospital or patient data.
