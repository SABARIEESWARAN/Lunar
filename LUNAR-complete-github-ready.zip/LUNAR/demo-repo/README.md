# Hospital Management System — LUNAR Demo Repository

> **IMPORTANT: This is a synthetic demonstration repository created for the LUNAR hackathon demo.**
> All data, credentials, patient IDs, and staff information are completely fictional.
> No real patient data is used anywhere in this repository.

## Purpose

This repository is deliberately seeded with realistic technical-debt problems so that the LUNAR
autonomous maintenance platform can demonstrate its full analysis → repair → verify workflow.

## Seeded Issues (for demonstration)

The following maintenance problems have been intentionally introduced:

| # | Category | Severity | Description |
|---|----------|----------|-------------|
| 1 | Security | HIGH | Hard-coded fake database password in config |
| 2 | Security | HIGH | Hard-coded fake API key in notification service |
| 3 | Complexity | HIGH | `schedule_appointment` function is 80+ lines with 12+ branches |
| 4 | Complexity | HIGH | `process_billing` function has deeply nested conditional logic |
| 5 | Duplication | MEDIUM | Patient age validation duplicated across two modules |
| 6 | Maintainability | MEDIUM | Weak/absent error handling in data access layer |
| 7 | Testing | HIGH | Core appointment scheduling, notification, and parts of billing/staff logic lack dedicated unit tests |
| 8 | Documentation | MEDIUM | Missing docstrings on critical public functions |
| 9 | Maintenance | LOW | TODO/FIXME markers that track real open work |
| 10 | Dependency | MEDIUM | Pinned to an old, known-issue version of a library |

## Fictional System Overview

A minimal hospital management system with modules for:
- Patient registration and records
- Appointment scheduling
- Staff management
- Billing and invoices
- Notification dispatch

## Setup (fictional — for demo display only)

```bash
pip install -r requirements.txt
python app.py
```

## Tests

The demo includes executable tests for patient registration plus a small cross-module smoke suite.
Coverage is intentionally incomplete so LUNAR can demonstrate test-gap detection.

```bash
pytest tests/
```

## Maintenance Notes

See LUNAR analysis for current technical-debt assessment.
