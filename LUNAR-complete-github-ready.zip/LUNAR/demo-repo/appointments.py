"""
Appointment scheduling module.
DEMO REPOSITORY — all data is fictional.
"""

import datetime
from config import MAX_APPOINTMENTS_PER_DAY, APPOINTMENT_SLOT_MINUTES, APPOINTMENT_TYPES


def validate_patient_age(age):
    # SEEDED ISSUE #5b — duplicated validation (same logic as in patients.py)
    if not isinstance(age, int):
        return False
    if age < 0 or age > 150:
        return False
    return True


def schedule_appointment(
    patient_id,
    doctor_id,
    appointment_date,
    appointment_type,
    patient_age,
    notes=None,
    priority=None,
    insurance_id=None,
    referring_doctor=None,
):
    """
    Schedule a new appointment for a patient.

    SEEDED ISSUE #3 — High complexity function:
    This function is too long (80+ lines) and has too many branches (12+).
    It handles scheduling logic, validation, conflict detection, insurance checks,
    priority queuing, and notification in a single function.
    """
    # Input validation block
    if not patient_id:
        raise ValueError("patient_id is required")
    if not doctor_id:
        raise ValueError("doctor_id is required")
    if not appointment_date:
        raise ValueError("appointment_date is required")
    if appointment_type not in APPOINTMENT_TYPES:
        raise ValueError(f"Unknown appointment type: {appointment_type}")

    # Validate patient age for appointment type
    if not validate_patient_age(patient_age):
        raise ValueError(f"Invalid patient age: {patient_age}")

    # Pediatric appointments need special handling
    if patient_age < 18:
        if appointment_type == "specialist_referral" and not referring_doctor:
            raise ValueError("Pediatric specialist referrals require a referring doctor")
        if appointment_type == "emergency":
            priority = "urgent"

    # Date validation
    if isinstance(appointment_date, str):
        try:
            appointment_date = datetime.datetime.fromisoformat(appointment_date)
        except ValueError:
            raise ValueError(f"Invalid date format: {appointment_date}")

    if appointment_date < datetime.datetime.now():
        raise ValueError("Cannot schedule appointments in the past")

    # Check daily limit
    existing = _get_appointments_for_date(doctor_id, appointment_date.date())
    if len(existing) >= MAX_APPOINTMENTS_PER_DAY:
        raise ValueError(f"Doctor {doctor_id} has reached the daily appointment limit")

    # Check for scheduling conflicts
    for existing_appt in existing:
        existing_time = existing_appt.get("time")
        if existing_time:
            diff = abs((appointment_date - existing_time).total_seconds() / 60)
            if diff < APPOINTMENT_SLOT_MINUTES:
                raise ValueError(
                    f"Scheduling conflict: appointment within {APPOINTMENT_SLOT_MINUTES} minutes of another"
                )

    # Insurance validation
    if insurance_id:
        if not _validate_insurance(insurance_id, appointment_type):
            if priority == "urgent":
                # Allow urgent appointments without valid insurance but flag it
                notes = (notes or "") + " [INSURANCE_UNVERIFIED]"
            else:
                raise ValueError(f"Insurance {insurance_id} does not cover {appointment_type}")

    # Set priority based on appointment type if not explicitly set
    if priority is None:
        if appointment_type == "emergency":
            priority = "urgent"
        elif appointment_type == "follow_up":
            priority = "normal"
        elif appointment_type == "specialist_referral":
            priority = "elevated"
        else:
            priority = "normal"

    # Build appointment record
    appointment = {
        "patient_id": patient_id,
        "doctor_id": doctor_id,
        "datetime": appointment_date.isoformat(),
        "type": appointment_type,
        "priority": priority,
        "notes": notes,
        "insurance_id": insurance_id,
        "referring_doctor": referring_doctor,
        "status": "scheduled",
    }

    _save_appointment(appointment)

    # Send notifications
    if priority == "urgent":
        _notify_urgent(patient_id, doctor_id, appointment_date)
    else:
        _notify_standard(patient_id, appointment_date)

    return appointment


def cancel_appointment(appointment_id, reason=None):
    """Cancel a scheduled appointment.

    # TODO: implement cancellation fee logic for late cancellations
    """
    appointment = _load_appointment(appointment_id)
    if appointment is None:
        raise ValueError(f"Appointment {appointment_id} not found")

    if appointment.get("status") == "cancelled":
        raise ValueError("Appointment is already cancelled")

    appointment["status"] = "cancelled"
    appointment["cancellation_reason"] = reason
    _save_appointment(appointment)
    return appointment


def get_appointments_for_patient(patient_id, include_cancelled=False):
    """Return all appointments for a patient."""
    # SEEDED ISSUE #8 — missing docstring content and no parameter type hints
    all_appts = _load_all_appointments()
    result = [a for a in all_appts if a["patient_id"] == patient_id]
    if not include_cancelled:
        result = [a for a in result if a.get("status") != "cancelled"]
    return result


def _get_appointments_for_date(doctor_id, date):
    return []  # Stub


def _validate_insurance(insurance_id, appointment_type):
    return True  # Stub


def _save_appointment(appointment):
    pass  # Stub


def _load_appointment(appointment_id):
    return None  # Stub


def _load_all_appointments():
    return []  # Stub


def _notify_urgent(patient_id, doctor_id, appointment_date):
    pass  # Stub


def _notify_standard(patient_id, appointment_date):
    pass  # Stub
