"""
Billing and invoice module.
DEMO REPOSITORY — all data is fictional.
"""

from config import APPOINTMENT_TYPES


PROCEDURE_COSTS = {
    "general_consultation": 150.00,
    "follow_up": 75.00,
    "emergency": 500.00,
    "specialist_referral": 300.00,
    "lab_results": 50.00,
}

INSURANCE_DISCOUNT_RATES = {
    "BASIC": 0.20,
    "STANDARD": 0.40,
    "PREMIUM": 0.60,
}


def process_billing(patient_id, appointment_id, appointment_type, insurance_plan=None, discount_code=None):
    """
    Process billing for a completed appointment.

    SEEDED ISSUE #4 — Deeply nested conditional logic
    This function has 4+ levels of nesting and mixes billing logic,
    discount calculation, insurance processing, and persistence.
    """
    if patient_id:
        if appointment_type in PROCEDURE_COSTS:
            base_cost = PROCEDURE_COSTS[appointment_type]
            final_cost = base_cost

            if insurance_plan:
                if insurance_plan.upper() in INSURANCE_DISCOUNT_RATES:
                    discount = INSURANCE_DISCOUNT_RATES[insurance_plan.upper()]
                    final_cost = base_cost * (1 - discount)
                    if discount_code:
                        if _validate_discount_code(discount_code):
                            if discount_code.startswith("VIP"):
                                final_cost = final_cost * 0.85
                            elif discount_code.startswith("SENIOR"):
                                final_cost = final_cost * 0.90
                            else:
                                final_cost = final_cost * 0.95
                else:
                    # Unknown insurance plan — charge full price
                    final_cost = base_cost
            else:
                if discount_code:
                    if _validate_discount_code(discount_code):
                        final_cost = base_cost * 0.95

            invoice = {
                "patient_id": patient_id,
                "appointment_id": appointment_id,
                "appointment_type": appointment_type,
                "base_cost": base_cost,
                "final_cost": round(final_cost, 2),
                "insurance_plan": insurance_plan,
                "discount_code": discount_code,
                "status": "pending",
            }

            # SEEDED ISSUE #6 — weak error handling around DB write
            _save_invoice(invoice)
            return invoice
        else:
            raise ValueError(f"Unknown appointment type for billing: {appointment_type}")
    else:
        raise ValueError("patient_id is required")


def get_invoice(invoice_id):
    # FIXME: add pagination for patients with many invoices
    return _load_invoice(invoice_id)


def _validate_discount_code(code):
    """Validate a discount code."""
    if not code:
        return False
    # HACK: currently accepts any non-empty string — needs real validation
    return len(code) > 3


def _save_invoice(invoice):
    pass  # Stub


def _load_invoice(invoice_id):
    return None  # Stub
