"""
Hospital Management System — Configuration
DEMO REPOSITORY: All values are fictional placeholders.
"""

# SEEDED ISSUE #1 — Hard-coded credential
# LUNAR should detect: hard-coded database password
DB_HOST = "localhost"
DB_PORT = 5432
DB_NAME = "hospital_demo_db"
DB_USER = "hms_admin"
DB_PASSWORD = "SuperSecret123!"  # TODO: move to environment variable

# SEEDED ISSUE #2 — Hard-coded API key
# LUNAR should detect: hard-coded API key for notification service
NOTIFICATION_API_KEY = "api_key_abc12345xyz_DEMO_ONLY"
NOTIFICATION_SERVICE_URL = "https://notify.example-demo.com/send"

# Application settings
APP_ENV = "development"
APP_DEBUG = True
MAX_APPOINTMENTS_PER_DAY = 50
APPOINTMENT_SLOT_MINUTES = 30

# Allowed appointment types
APPOINTMENT_TYPES = [
    "general_consultation",
    "follow_up",
    "emergency",
    "specialist_referral",
    "lab_results",
]
