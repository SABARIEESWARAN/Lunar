"""
Notification dispatch module.
DEMO REPOSITORY — all data is fictional.
"""

import requests
from config import NOTIFICATION_API_KEY, NOTIFICATION_SERVICE_URL


def send_appointment_reminder(patient_email, appointment_details):
    """Send an appointment reminder to a patient."""
    payload = {
        "to": patient_email,
        "subject": "Appointment Reminder",
        "body": _build_reminder_body(appointment_details),
    }
    headers = {
        "Authorization": f"Bearer {NOTIFICATION_API_KEY}",
        "Content-Type": "application/json",
    }
    # SEEDED ISSUE #6 — weak error handling: exception from requests not caught
    response = requests.post(NOTIFICATION_SERVICE_URL, json=payload, headers=headers)
    return response.status_code == 200


def send_cancellation_notice(patient_email, appointment_id, reason=None):
    """Send a cancellation notice."""
    payload = {
        "to": patient_email,
        "subject": "Appointment Cancelled",
        "body": f"Your appointment {appointment_id} has been cancelled. Reason: {reason or 'Not specified'}",
    }
    headers = {"Authorization": f"Bearer {NOTIFICATION_API_KEY}"}
    response = requests.post(NOTIFICATION_SERVICE_URL, json=payload, headers=headers)
    return response.status_code == 200


def _build_reminder_body(appointment_details):
    return (
        f"Dear Patient,\n\n"
        f"This is a reminder for your appointment on "
        f"{appointment_details.get('datetime', 'TBD')} "
        f"with Doctor {appointment_details.get('doctor_id', 'TBD')}.\n\n"
        f"Type: {appointment_details.get('type', 'General Consultation')}\n\n"
        f"Please arrive 10 minutes early. This is a fictional demo message."
    )
