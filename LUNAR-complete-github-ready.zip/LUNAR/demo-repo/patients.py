"""
Patient registration and records module.
DEMO REPOSITORY — all data is fictional.
"""


def validate_patient_age(age):
    # SEEDED ISSUE #5a — duplicated validation (same logic in appointments.py)
    if not isinstance(age, int):
        return False
    if age < 0 or age > 150:
        return False
    return True


def validate_patient_id(patient_id):
    """Check that a patient ID matches the required format."""
    if not patient_id:
        return False
    if not isinstance(patient_id, str):
        return False
    # Patient IDs must be 8 alphanumeric characters
    import re
    return bool(re.match(r"^[A-Z]{2}\d{6}$", patient_id))


def register_patient(name, age, patient_id, contact_email, blood_type=None):
    """Register a new patient in the system.

    Returns a patient record dict or raises ValueError on invalid input.
    """
    if not name or not isinstance(name, str):
        raise ValueError("Patient name is required")

    if not validate_patient_age(age):
        raise ValueError(f"Invalid age: {age}")

    if not validate_patient_id(patient_id):
        raise ValueError(f"Invalid patient ID format: {patient_id}")

    record = {
        "patient_id": patient_id,
        "name": name,
        "age": age,
        "contact_email": contact_email,
        "blood_type": blood_type,
        "status": "active",
    }

    # SEEDED ISSUE #6 — weak error handling: no exception handling around DB write
    # If the DB is unavailable this will raise an unhandled exception
    _save_patient_to_db(record)
    return record


def _save_patient_to_db(record):
    # FIXME: replace with actual database layer
    # For demo purposes, this is a no-op stub
    pass


def get_patient(patient_id):
    # SEEDED ISSUE #6 — weak error handling: returns None silently on failure
    try:
        return _load_patient_from_db(patient_id)
    except Exception:
        return None  # Swallows all errors silently


def _load_patient_from_db(patient_id):
    # Stub — in production this would query the database
    return {"patient_id": patient_id, "name": "Demo Patient", "status": "active"}


def deactivate_patient(patient_id, reason=None):
    """Mark a patient record as inactive."""
    # TODO: add audit trail for patient deactivation
    record = get_patient(patient_id)
    if record:
        record["status"] = "inactive"
        record["deactivation_reason"] = reason
        _save_patient_to_db(record)
    return record
