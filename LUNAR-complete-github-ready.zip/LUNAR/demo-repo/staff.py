"""
Staff management module.
DEMO REPOSITORY — all data is fictional.
"""


STAFF_ROLES = ["doctor", "nurse", "receptionist", "admin", "specialist"]


def register_staff(name, role, department, license_number=None):
    """Register a new staff member."""
    if not name:
        raise ValueError("Name is required")
    if role not in STAFF_ROLES:
        raise ValueError(f"Invalid role: {role}. Must be one of {STAFF_ROLES}")
    if role == "doctor" and not license_number:
        raise ValueError("Medical license number is required for doctors")

    record = {
        "name": name,
        "role": role,
        "department": department,
        "license_number": license_number,
        "active": True,
    }
    _save_staff(record)
    return record


def get_available_doctors(department=None, date=None):
    """Return list of available doctors, optionally filtered by department or date."""
    # TODO: implement schedule-based availability check
    doctors = _load_all_staff(role="doctor")
    if department:
        doctors = [d for d in doctors if d.get("department") == department]
    return doctors


def _save_staff(record):
    pass  # Stub


def _load_all_staff(role=None):
    return []  # Stub
