"""Small executable tests for the synthetic LUNAR hospital demo."""
from appointments import validate_patient_age
from billing import process_billing
from patients import validate_patient_id, register_patient
from staff import register_staff


def test_patient_age_boundaries():
    assert validate_patient_age(0)
    assert validate_patient_age(150)
    assert not validate_patient_age(-1)
    assert not validate_patient_age(151)


def test_patient_id_and_registration():
    assert validate_patient_id("AB123456")
    assert not validate_patient_id("bad")
    record = register_patient("Demo Patient", 30, "AB123456", "demo@example.invalid")
    assert record["status"] == "active"


def test_staff_registration():
    doctor = register_staff("Demo Doctor", "doctor", "Cardiology", "LIC-DEMO-001")
    assert doctor["active"] is True


def test_billing_with_standard_insurance():
    invoice = process_billing("AB123456", "APT-DEMO-001", "general_consultation", "STANDARD")
    assert invoice["final_cost"] == 90.0
