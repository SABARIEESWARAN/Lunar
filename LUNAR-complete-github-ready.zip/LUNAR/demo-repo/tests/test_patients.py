"""
Tests for patient registration module.
DEMO REPOSITORY — all data is fictional.

Note: SEEDED ISSUE #7 — No tests exist for appointment scheduling,
billing, or notification modules (the most business-critical paths).
These tests only cover the patient module.
"""

import pytest
from patients import validate_patient_age, validate_patient_id, register_patient


class TestValidatePatientAge:
    def test_valid_adult_age(self):
        assert validate_patient_age(35) is True

    def test_valid_newborn(self):
        assert validate_patient_age(0) is True

    def test_valid_elderly(self):
        assert validate_patient_age(99) is True

    def test_invalid_negative(self):
        assert validate_patient_age(-1) is False

    def test_invalid_too_old(self):
        assert validate_patient_age(151) is False

    def test_invalid_string(self):
        assert validate_patient_age("thirty") is False


class TestValidatePatientId:
    def test_valid_id(self):
        assert validate_patient_id("AB123456") is True

    def test_invalid_too_short(self):
        assert validate_patient_id("AB12345") is False

    def test_invalid_lowercase(self):
        assert validate_patient_id("ab123456") is False

    def test_invalid_empty(self):
        assert validate_patient_id("") is False

    def test_invalid_none(self):
        assert validate_patient_id(None) is False


class TestRegisterPatient:
    def test_valid_registration(self):
        record = register_patient("Jane Demo", 30, "AB123456", "jane@demo.example")
        assert record["patient_id"] == "AB123456"
        assert record["status"] == "active"

    def test_missing_name_raises(self):
        with pytest.raises(ValueError, match="name is required"):
            register_patient("", 30, "AB123456", "jane@demo.example")

    def test_invalid_age_raises(self):
        with pytest.raises(ValueError, match="Invalid age"):
            register_patient("Jane Demo", -5, "AB123456", "jane@demo.example")

    def test_invalid_id_raises(self):
        with pytest.raises(ValueError, match="Invalid patient ID"):
            register_patient("Jane Demo", 30, "bad-id", "jane@demo.example")
