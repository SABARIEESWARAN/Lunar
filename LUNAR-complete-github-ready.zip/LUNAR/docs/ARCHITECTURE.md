# LUNAR Architecture

## Layers

React UI → FastAPI API → Orchestrator → Repository Workspace → Agents → Verification → MongoDB history.

## Safety boundary

The public repository is read-only during analysis. Repairs happen only in a temporary workspace. Medium/high-risk changes require approval.

## Agent protocol

All agents communicate through structured findings. This makes results auditable and prevents one agent's prose from becoming another agent's implicit truth.

## Parallelism

Code Intelligence, Security/Dependencies, and Tests/Documentation run independently. Debt Analyst waits for all three.

## Verification

A repair is not successful because the model says it worked. Build/test/static/security evidence is required.
