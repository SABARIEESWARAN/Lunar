# LUNAR Demo Scenario

## Seeded hospital-management repository

Create a small public demo repository with:
1. hard-coded database credential
2. high-complexity appointment function
3. duplicated patient validation
4. missing tests around appointment cancellation
5. outdated/deprecated dependency
6. TODO/FIXME markers
7. missing README
8. weak error handling

## Demo flow

1. Paste public GitHub URL.
2. LUNAR discovers repository stats.
3. Start analysis.
4. Show three agents running in parallel.
5. Show findings and evidence.
6. Open the critical security finding.
7. Ask LUNAR chat to prepare a fix.
8. Show risk and Git-style diff.
9. Approve the fix.
10. Run verification.
11. Show before/after metrics.
12. Open maintenance history.

## Benchmark

Run the same task manually and with LUNAR at least three times if possible.

Record:
- time
- number of manual investigation actions
- findings detected
- true positives
- false positives
- fix preparation time
- verification time
- regression count
- debt estimate before/after
- health score before/after

Report actual median values.
