# LUNAR Maintenance Workflow

LUNAR turns repository maintenance into an auditable loop:

```text
SCAN → UNDERSTAND → PRIORITIZE → REPAIR → APPROVE → VERIFY → MEASURE
```

## 1. Scan

The repository is copied into an isolated workspace. The original public repository is not modified during analysis.

Three deterministic analysis groups inspect the workspace:

- Code Intelligence
- Security & Dependencies
- Tests & Documentation

## 2. Understand

Each finding contains structured evidence such as file path, line, category, severity, confidence, recommendation, and estimated effort.

## 3. Prioritize

The Technical Debt Analyst consolidates findings and calculates a LUNAR-specific priority score. High-impact and high-risk findings rise to the top.

## 4. Repair

For supported low-risk transformations, LUNAR prepares a repair in a temporary workspace. The original repository remains untouched.

## 5. Approve

Medium/high-risk changes require explicit developer approval before they are applied.

## 6. Verify

LUNAR runs available tests and static checks and compares repository metrics before and after the change.

## 7. Measure

The result can include:

- findings before/after;
- estimated maintenance effort before/after;
- health indicator before/after;
- test results;
- regression information;
- verification checks.

## Developer control

The system recommends and prepares changes. The developer remains the final decision-maker for repairs.
