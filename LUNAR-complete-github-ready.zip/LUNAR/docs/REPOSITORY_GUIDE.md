# Repository Guide

## Product code

- `backend/` — FastAPI API, orchestration, scanners, scoring, repair, and verification.
- `frontend/` — React/Vite dashboard.
- `bob-prompts/` — structured Bob agent prompts and handoff contracts.

## Demonstration target

- `demo-repo/` — deliberately imperfect synthetic hospital-management repository.

This is not production application code. It is the controlled target used to demonstrate how LUNAR detects and maintains an existing codebase.

## Documentation

- `README.md` — project overview and local setup.
- `docs/ARCHITECTURE.md` — architecture and safety boundary.
- `docs/MAINTENANCE_WORKFLOW.md` — end-to-end maintenance lifecycle.
- `docs/DEMO.md` — demonstration procedure and measurement plan.
- `docs/SUBMISSION.md` — hackathon submission narrative.
- `TECHNICAL_DEBT.md` — debt categories, scoring, repair, and verification rules.

## Development checks

Backend:

```bash
cd backend
python -m pytest
```

Frontend:

```bash
cd frontend
npm ci
npm run build
```
