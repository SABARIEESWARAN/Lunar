# LUNAR — Submission Description

## One-line pitch

LUNAR is an autonomous software-maintenance system that detects, prioritizes, repairs, and verifies technical debt across a codebase.

## Problem

Technical debt is rarely a single bug. It accumulates as duplicated logic, complexity, dependency risk, missing tests, documentation gaps, insecure patterns, and deferred maintenance. Developers often discover these issues piecemeal and then spend additional time determining what matters, how risky a change is, and whether a repair introduced a regression.

## Solution

LUNAR turns maintenance into a measurable workflow:

SCAN → UNDERSTAND → PRIORITIZE → REPAIR → APPROVE → VERIFY → MEASURE → REMEMBER

A public GitHub repository is analyzed by parallel specialist agents. Their evidence is consolidated into a technical-debt model. LUNAR prepares fixes in an isolated temporary workspace, shows a developer-facing diff, applies risk-based approval gates, verifies the change, and records before/after metrics.

## IBM Bob 2.0 role

IBM Bob 2.0 is used as the agentic development partner for repository-aware analysis, parallel specialist tasks, repair planning, verification, and document understanding. The project is deliberately structured around subagents and auditable handoffs rather than a single chat completion.

## Differentiator

LUNAR does not stop at finding code problems. It closes the maintenance loop and proves whether a proposed repair improved the codebase without introducing regressions.

## Demo

The demo uses a deliberately seeded hospital-management repository with 5–10 known maintenance problems. The flow shows parallel agents, prioritized findings, an approved repair, verification, and a before/after maintenance report.

## Impact metrics

The prototype measures:
- time to understand a high-priority issue
- manual investigation steps
- findings and false positives
- repair preparation time
- verification time
- regressions
- health score
- estimated technical-debt hours
- test coverage where measurable

All published numbers should be measured during the demo rather than assumed.
