import React, { useState, useEffect, useRef, useCallback } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const API = import.meta.env.VITE_API_URL || "";

// ─── API helpers ──────────────────────────────────────────────────────────────

async function apiFetch(path, opts = {}) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.detail || `HTTP ${res.status}`);
  return json;
}

// ─── App root ─────────────────────────────────────────────────────────────────

function App() {
  const [url, setUrl] = useState("demo://hospital");
  const [jobId, setJobId] = useState(null);
  const [job, setJob] = useState(null);   // full job status object
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState("overview"); // overview | findings | agents | repair | verify
  const [selectedFinding, setSelectedFinding] = useState(null);
  const [repair, setRepair] = useState(null);      // current repair proposal
  const [verification, setVerification] = useState(null);
  const [diffData, setDiffData] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState(null);
  const [messages, setMessages] = useState([
    { role: "ai", text: "I'm LUNAR. Give me a public GitHub repository and I'll map its maintenance risks." },
  ]);
  const [chat, setChat] = useState("");
  const pollRef = useRef(null);

  // ── Poll job status ──────────────────────────────────────────────────────
  const startPolling = useCallback((id) => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const j = await apiFetch(`/api/analyze/${id}`);
        setJob(j);
        if (j.status === "completed" || j.status === "failed") {
          clearInterval(pollRef.current);
          pollRef.current = null;
          setLoading(false);
          if (j.status === "failed") {
            setMessages((m) => [...m, { role: "ai", text: `Analysis failed: ${j.error}` }]);
          }
        }
      } catch (e) {
        clearInterval(pollRef.current);
        setLoading(false);
      }
    }, 1500);
  }, []);

  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  async function analyze() {
    if (!url.trim()) return;
    setLoading(true);
    setJob(null);
    setJobId(null);
    setSelectedFinding(null);
    setRepair(null);
    setVerification(null);
    setDiffData(null);
    setActionError(null);
    setView("overview");
    try {
      const res = await apiFetch("/api/analyze", {
        method: "POST",
        body: JSON.stringify({ repo_url: url }),
      });
      setJobId(res.job_id);
      setJob({ job_id: res.job_id, status: "queued", progress: 0, stage: "queued", result: null });
      startPolling(res.job_id);
      setMessages((m) => [...m, { role: "user", text: `Analyze: ${url}` }, { role: "ai", text: "Analysis started. Running parallel agents…" }]);
    } catch (e) {
      setLoading(false);
      setMessages((m) => [...m, { role: "ai", text: e.message }]);
    }
  }

  // ── Repair actions ────────────────────────────────────────────────────────

  async function prepareFix(finding) {
    setActionLoading(true);
    setActionError(null);
    setRepair(null);
    setDiffData(null);
    setVerification(null);
    try {
      const r = await apiFetch("/api/repair", {
        method: "POST",
        body: JSON.stringify({ job_id: jobId, finding_id: finding.id }),
      });
      setRepair(r);
      setView("repair");
      if (r.status === "manual_review_required") {
        setMessages((m) => [...m, { role: "ai", text: `Manual review required: ${r.reason}` }]);
      } else {
        setMessages((m) => [...m, { role: "ai", text: `Repair proposed for ${finding.title}. Review the diff before approving.` }]);
      }
    } catch (e) {
      setActionError(e.message);
    } finally {
      setActionLoading(false);
    }
  }

  async function viewDiff() {
    if (!repair?.repair_id) return;
    setActionLoading(true);
    setActionError(null);
    try {
      const d = await apiFetch(`/api/repair/${repair.repair_id}/diff`);
      setDiffData(d);
    } catch (e) {
      setActionError(e.message);
    } finally {
      setActionLoading(false);
    }
  }

  async function approveRepair() {
    if (!repair?.repair_id) return;
    setActionLoading(true);
    setActionError(null);
    try {
      const r = await apiFetch(`/api/repair/${repair.repair_id}/approve`, { method: "POST" });
      setRepair((prev) => ({ ...prev, status: r.status }));
      setMessages((m) => [...m, { role: "ai", text: "Repair approved. Run verification to confirm the change is safe." }]);
    } catch (e) {
      setActionError(e.message);
    } finally {
      setActionLoading(false);
    }
  }

  async function rejectRepair() {
    if (!repair?.repair_id) return;
    setActionLoading(true);
    setActionError(null);
    try {
      const r = await apiFetch(`/api/repair/${repair.repair_id}/reject`, { method: "POST" });
      setRepair((prev) => ({ ...prev, status: r.status }));
      setMessages((m) => [...m, { role: "ai", text: "Repair rejected and workspace cleaned up." }]);
    } catch (e) {
      setActionError(e.message);
    } finally {
      setActionLoading(false);
    }
  }

  async function runVerification() {
    if (!repair?.repair_id) return;
    setActionLoading(true);
    setActionError(null);
    try {
      const v = await apiFetch(`/api/verify/${repair.repair_id}`, { method: "POST" });
      setVerification(v);
      setRepair((prev) => ({ ...prev, status: v.status === "passed" ? "verified" : "verification_failed" }));
      setView("verify");
      setMessages((m) => [...m, { role: "ai", text: v.summary }]);
    } catch (e) {
      setActionError(e.message);
    } finally {
      setActionLoading(false);
    }
  }

  // ── Chat ─────────────────────────────────────────────────────────────────

  function ask() {
    if (!chat.trim()) return;
    const userMsg = chat;
    setChat("");
    let aiReply = "Analysis context is not loaded yet. Start an analysis first.";
    if (job?.result) {
      const data = job.result;
      if (userMsg.toLowerCase().includes("critical")) {
        const criticals = data.findings.filter((f) => f.severity === "critical");
        aiReply = criticals.length > 0
          ? `${criticals.length} critical finding(s): ${criticals.map((f) => f.title).join(", ")}.`
          : "No critical findings detected.";
      } else if (userMsg.toLowerCase().includes("health")) {
        aiReply = `Health score: ${data.health_score}/100. Technical debt: ${data.technical_debt_hours}h estimated.`;
      } else if (userMsg.toLowerCase().includes("fix") || userMsg.toLowerCase().includes("repair")) {
        aiReply = selectedFinding
          ? `Select 'PREPARE FIX' on the finding panel to generate a repair proposal for: ${selectedFinding.title}.`
          : "Select a finding from the Priority Findings list, then use PREPARE FIX.";
      } else {
        aiReply = `Repository scanned: ${data.repository.files} files, ${data.findings.length} findings, health ${data.health_score}/100, debt ${data.technical_debt_hours}h.`;
      }
    }
    setMessages((m) => [...m, { role: "user", text: userMsg }, { role: "ai", text: aiReply }]);
  }

  const data = job?.result;

  return (
    <div className="app">
      <aside>
        <div className="logo">LUNAR<span>●</span></div>
        <div className="tag">AUTONOMOUS MAINTENANCE</div>
        <nav>
          <b onClick={() => setView("overview")} style={{ cursor: "pointer" }}>Overview</b>
          <span onClick={() => setView("findings")} style={{ cursor: "pointer", background: view === "findings" ? "#151e2c" : undefined, color: view === "findings" ? "#fff" : undefined }}>Findings</span>
          <span onClick={() => setView("agents")} style={{ cursor: "pointer", background: view === "agents" ? "#151e2c" : undefined, color: view === "agents" ? "#fff" : undefined }}>Agents</span>
          {repair && <span onClick={() => setView("repair")} style={{ cursor: "pointer", background: view === "repair" ? "#151e2c" : undefined, color: view === "repair" ? "#fff" : undefined }}>Repair</span>}
          {verification && <span onClick={() => setView("verify")} style={{ cursor: "pointer", background: view === "verify" ? "#151e2c" : undefined, color: view === "verify" ? "#fff" : undefined }}>Verification</span>}
        </nav>
        <div className="sidecard">
          <small>WORKSPACE</small>
          <strong>Hospital Demo</strong>
          <span>Public repository</span>
        </div>
      </aside>

      <main>
        <header>
          <div>
            <small>REPOSITORY / ANALYSIS</small>
            <h1>Codebase Health</h1>
          </div>
          <div className="live" style={{ color: loading ? "#78a7ff" : data ? "#73d6a2" : "#73d6a2" }}>
            ● {loading ? "ANALYZING" : data ? "ANALYSIS COMPLETE" : "SYSTEM READY"}
          </div>
        </header>

        <section className="repo">
          <input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !loading && analyze()}
            placeholder="https://github.com/owner/public-repository"
          />
          <button onClick={analyze} disabled={loading || !url.trim()}>
            {loading ? "ANALYZING…" : "START ANALYSIS"}
          </button>
          <button className="secondary" onClick={() => { setUrl("demo://hospital"); }} disabled={loading}>
            LOAD HOSPITAL DEMO
          </button>
        </section>

        {/* Progress bar during analysis */}
        {loading && job && (
          <div style={{ margin: "14px 0" }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#66758a", marginBottom: 6 }}>
              <span>{STAGE_LABELS[job.stage] || job.stage}</span>
              <span>{job.progress}%</span>
            </div>
            <div style={{ background: "#111a28", borderRadius: 6, height: 6 }}>
              <div style={{ background: "#4d7cff", height: 6, borderRadius: 6, width: `${job.progress}%`, transition: "width 0.4s ease" }} />
            </div>
          </div>
        )}

        {actionError && (
          <div style={{ background: "#1e1020", border: "1px solid #7c1f2e", borderRadius: 8, padding: "10px 14px", marginBottom: 12, fontSize: 13, color: "#f87171" }}>
            {actionError}
          </div>
        )}

        {!data && !loading && <EmptyState />}

        {data && view === "overview" && (
          <Dashboard
            data={data}
            selectedFinding={selectedFinding}
            setSelectedFinding={setSelectedFinding}
            onPrepareFix={prepareFix}
            onViewDiff={viewDiff}
            repair={repair}
            actionLoading={actionLoading}
          />
        )}
        {data && view === "findings" && (
          <FindingsView
            data={data}
            selectedFinding={selectedFinding}
            setSelectedFinding={setSelectedFinding}
            onPrepareFix={prepareFix}
            repair={repair}
            actionLoading={actionLoading}
          />
        )}
        {data && view === "agents" && <AgentsView data={data} />}
        {view === "repair" && repair && (
          <RepairView
            repair={repair}
            diffData={diffData}
            onViewDiff={viewDiff}
            onApprove={approveRepair}
            onReject={rejectRepair}
            onVerify={runVerification}
            actionLoading={actionLoading}
          />
        )}
        {view === "verify" && verification && (
          <VerificationView verification={verification} />
        )}
      </main>

      <section className="chat">
        <div className="chathead"><b>LUNAR AI</b><span>● Online</span></div>
        <div className="msgs">
          {messages.map((m, i) => (
            <div key={i} className={m.role}>{m.text}</div>
          ))}
        </div>
        <div className="chatbox">
          <input
            value={chat}
            onChange={(e) => setChat(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && ask()}
            placeholder="Ask about this codebase…"
          />
          <button onClick={ask}>↑</button>
        </div>
      </section>
    </div>
  );
}

// ─── Stage labels ─────────────────────────────────────────────────────────────

const STAGE_LABELS = {
  queued: "Queued",
  cloning: "Cloning repository…",
  scanning: "Starting parallel agents…",
  agent_code_intelligence_completed: "Code intelligence agent done",
  agent_security_dependencies_completed: "Security agent done",
  agent_test_documentation_completed: "Tests & docs agent done",
  consolidating: "Consolidating findings…",
  completed: "Analysis complete",
  failed: "Analysis failed",
};

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyState() {
  return (
    <section className="empty">
      <div className="orb">L</div>
      <h2>Turn technical debt into verified maintenance</h2>
      <p>Connect a public GitHub repository to run LUNAR's parallel analysis workflow.</p>
    </section>
  );
}

// ─── Overview Dashboard ───────────────────────────────────────────────────────

function Dashboard({ data, selectedFinding, setSelectedFinding, onPrepareFix, onViewDiff, repair, actionLoading }) {
  const s = data.severity_counts;
  return (
    <div>
      <div className="metrics">
        <Metric label="CODE HEALTH" value={data.health_score + "/100"} trend="Higher is healthier" />
        <Metric label="TECHNICAL DEBT" value={data.technical_debt_hours + "h"} trend="Estimated remediation" />
        <Metric label="CRITICAL" value={s.CRITICAL || 0} trend="Immediate attention" />
        <Metric label="HIGH" value={s.HIGH || 0} trend="Priority findings" />
      </div>

      <div className="grid">
        <div className="panel">
          <div className="paneltitle"><b>Agent Network</b><span>{data.analysis_seconds}s</span></div>
          <div className="agents">
            {Object.entries(data.agent_status).map(([k, v]) => {
              const status = typeof v === "object" ? v.status : v;
              const count = typeof v === "object" ? v.findings : null;
              const isDone = status === "completed";
              return (
                <div className="agent" key={k}>
                  <i className={isDone ? "done" : ""}></i>
                  <span>{k.replaceAll("_", " ")}</span>
                  <em>{isDone && count != null ? `${count} findings` : status.replaceAll("_", " ")}</em>
                </div>
              );
            })}
          </div>
        </div>
        <div className="panel">
          <div className="paneltitle"><b>Repository</b><span>{data.repository.files} files</span></div>
          <div className="repoStats">
            <strong>{data.repository.lines.toLocaleString()}</strong>
            <span>lines analyzed</span>
            {Object.entries(data.repository.languages).map(([k, v]) => (
              <div key={k}>{k}<b>{v} files</b></div>
            ))}
          </div>
        </div>
      </div>

      {data.priority_summary?.immediate_action_required && (
        <div style={{ background: "#1e0a0a", border: "1px solid #7c1f2e", borderRadius: 8, padding: "10px 14px", marginBottom: 14, fontSize: 12, color: "#f87171" }}>
          ⚠ CRITICAL findings detected — immediate action required. See Priority Findings below.
        </div>
      )}
      <div className="panel">
        <div className="paneltitle">
          <b>Priority Findings</b>
          <span>{data.total_findings || data.findings.length} detected · {data.priority_summary?.repairable_count || 0} auto-repairable</span>
        </div>
        <div className="findings">
          {data.findings.slice(0, 10).map((f) => (
            <button
              className={"finding" + (selectedFinding?.id === f.id ? " selected" : "")}
              onClick={() => setSelectedFinding(f)}
              key={f.id}
            >
              <span className={"sev " + f.severity}>{f.severity.toUpperCase()}</span>
              <div>
                <b>{f.title}</b>
                <small>{f.file}{f.line ? `:${f.line}` : ""}</small>
                {f.repairable && <small style={{ color: "#73d6a2", marginLeft: 8 }}>● auto-repair</small>}
              </div>
              <strong>{f.estimated_effort_min}m</strong>
            </button>
          ))}
        </div>
      </div>

      {selectedFinding && (
        <FindingDetail
          finding={selectedFinding}
          onClose={() => setSelectedFinding(null)}
          onPrepareFix={onPrepareFix}
          repair={repair}
          actionLoading={actionLoading}
        />
      )}
    </div>
  );
}

// ─── Findings View ────────────────────────────────────────────────────────────

function FindingsView({ data, selectedFinding, setSelectedFinding, onPrepareFix, repair, actionLoading }) {
  const [filter, setFilter] = useState("all");
  const filtered = filter === "all" ? data.findings : data.findings.filter((f) => f.severity === filter);

  return (
    <div>
      <div className="panel">
        <div className="paneltitle">
          <b>All Findings</b>
          <div style={{ display: "flex", gap: 8 }}>
            {["all", "critical", "high", "medium", "low"].map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                style={{
                  background: filter === s ? "#172235" : "transparent",
                  border: "1px solid #30415a",
                  color: "#cdd9e8",
                  borderRadius: 6,
                  padding: "3px 10px",
                  fontSize: 10,
                  cursor: "pointer",
                  fontWeight: 600,
                  letterSpacing: ".5px",
                  textTransform: "uppercase",
                }}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
        <div className="findings">
          {filtered.map((f) => (
            <button
              className={"finding" + (selectedFinding?.id === f.id ? " selected" : "")}
              onClick={() => setSelectedFinding(f)}
              key={f.id}
            >
              <span className={"sev " + f.severity}>{f.severity.toUpperCase()}</span>
              <div>
                <b>{f.title}</b>
                <small>{f.file}</small>
                {f.repairable && <small style={{ color: "#73d6a2", marginLeft: 8 }}>● Auto-repairable</small>}
              </div>
              <strong>{f.estimated_effort_min}m</strong>
            </button>
          ))}
        </div>
      </div>

      {selectedFinding && (
        <FindingDetail
          finding={selectedFinding}
          onClose={() => setSelectedFinding(null)}
          onPrepareFix={onPrepareFix}
          repair={repair}
          actionLoading={actionLoading}
        />
      )}
    </div>
  );
}

// ─── Agents View ──────────────────────────────────────────────────────────────

const AGENT_DESCRIPTIONS = {
  code_intelligence: "AST complexity, duplication, maintenance markers, silent error handlers",
  security_dependencies: "Hard-coded credentials, dynamic execution, shell injection, outdated dependencies",
  test_documentation: "Test coverage gaps, missing README, missing docstrings",
  debt_analyst: "Consolidation, evidence-based priority scoring, AI recommendations",
  repair: "Isolated patch generation in temporary workspace — never modifies original repo",
  verification: "Syntax checks, test runner, before/after metric comparison",
};

function AgentsView({ data }) {
  return (
    <div>
      <div className="panel">
        <div className="paneltitle"><b>Six-Agent Workflow</b><span>{data.analysis_seconds}s analysis</span></div>
        <div className="agents">
          {Object.entries(data.agent_status).map(([k, v]) => {
            const status = typeof v === "object" ? v.status : v;
            const count = typeof v === "object" ? v.findings : null;
            const elapsedMs = typeof v === "object" ? v.elapsed_ms : null;
            const isDone = status === "completed";
            const isWaiting = status.includes("waiting");
            return (
              <div className="agent" key={k} style={{ padding: "10px 0" }}>
                <i className={isDone ? "done" : ""}></i>
                <div style={{ flex: 1 }}>
                  <span style={{ display: "block", fontSize: 13, fontWeight: 600 }}>
                    {k.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase())}
                  </span>
                  <small style={{ color: "#66758a" }}>{AGENT_DESCRIPTIONS[k] || ""}</small>
                  {isDone && count != null && (
                    <small style={{ color: "#73d6a2", display: "block", marginTop: 2 }}>
                      {count} finding{count !== 1 ? "s" : ""}{elapsedMs ? ` · ${elapsedMs}ms` : ""}
                    </small>
                  )}
                </div>
                <em style={{ color: isDone ? "#73d6a2" : isWaiting ? "#66758a" : "#78a7ff", fontSize: 10 }}>
                  {status.replaceAll("_", " ")}
                </em>
              </div>
            );
          })}
        </div>
      </div>
      <div className="panel" style={{ marginTop: 14 }}>
        <div className="paneltitle"><b>Category Breakdown</b></div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginTop: 4 }}>
          {Object.entries(data.category_counts).map(([cat, count]) => (
            <div key={cat} style={{ background: "#0d131e", border: "1px solid #263448", borderRadius: 8, padding: "8px 14px", fontSize: 12 }}>
              <div style={{ color: "#66758a", fontSize: 10, textTransform: "uppercase", letterSpacing: ".5px" }}>{cat}</div>
              <div style={{ fontSize: 20, fontWeight: 700, color: "#dce7f5" }}>{count}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Finding Detail ───────────────────────────────────────────────────────────

function FindingDetail({ finding, onClose, onPrepareFix, repair, actionLoading }) {
  const alreadyRepaired = repair && repair.finding_id === finding.id;
  const rec = finding.ai_recommendation || {};

  return (
    <div className="panel detail">
      <div className="paneltitle">
        <b>{finding.title}</b>
        <button onClick={onClose} style={{ background: "none", border: "none", color: "#8d9aad", fontSize: 18, cursor: "pointer" }}>×</button>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 10 }}>
        <span className={"sev " + finding.severity}>{finding.severity.toUpperCase()}</span>
        <span style={{ fontSize: 10, background: "#111a28", border: "1px solid #263448", borderRadius: 4, padding: "3px 8px", color: "#8d9aad" }}>{finding.category}</span>
        {finding.repairable && <span style={{ fontSize: 10, background: "#0d2818", border: "1px solid #244a3c", borderRadius: 4, padding: "3px 8px", color: "#73d6a2" }}>● auto-repairable</span>}
        {finding.priority_score > 0 && (
          <span style={{ fontSize: 10, background: "#111a28", border: "1px solid #263448", borderRadius: 4, padding: "3px 8px", color: "#78a7ff" }}>
            priority {finding.priority_score}
          </span>
        )}
      </div>

      <p><b>File:</b> <code style={{ fontSize: 11 }}>{finding.file}{finding.line ? `:${finding.line}` : ""}</code></p>
      <p><b>Evidence:</b> {finding.evidence}</p>

      {rec.what_is_wrong && (
        <div style={{ background: "#0d131e", border: "1px solid #1b2534", borderRadius: 8, padding: "12px", margin: "10px 0" }}>
          <div style={{ fontSize: 10, color: "#66758a", textTransform: "uppercase", letterSpacing: ".5px", marginBottom: 8 }}>LUNAR AI Recommendation</div>
          <p style={{ color: "#dce7f5", marginBottom: 6 }}><b>What:</b> {rec.what_is_wrong}</p>
          <p style={{ color: "#a8b5c6", marginBottom: 6 }}><b>Why it matters:</b> {rec.why_it_matters}</p>
          <p style={{ color: "#a8b5c6", marginBottom: 6 }}><b>Action:</b> {rec.recommended_action}</p>
          <div style={{ display: "flex", gap: 14, fontSize: 11, color: "#66758a", marginTop: 8 }}>
            <span>⏱ {rec.estimated_effort}</span>
            <span>⚡ Risk: {rec.risk_level}</span>
            <span style={{ color: rec.lunar_can_automate ? "#73d6a2" : "#8d9aad" }}>
              {rec.lunar_can_automate ? "✓ LUNAR can automate" : "○ Manual repair needed"}
            </span>
          </div>
          {rec.verification_required && (
            <p style={{ marginTop: 8, fontSize: 10, color: "#66758a" }}>🔍 Verification: {rec.verification_required}</p>
          )}
        </div>
      )}

      <div className="actions">
        {!alreadyRepaired && (
          <button
            className="primary"
            onClick={() => onPrepareFix(finding)}
            disabled={actionLoading}
          >
            {actionLoading ? "PREPARING…" : "PREPARE FIX"}
          </button>
        )}
        {alreadyRepaired && (
          <span style={{ fontSize: 12, color: "#73d6a2" }}>✓ Repair proposed — see Repair panel</span>
        )}
      </div>
    </div>
  );
}

// ─── Repair View ──────────────────────────────────────────────────────────────

function RepairView({ repair, diffData, onViewDiff, onApprove, onReject, onVerify, actionLoading }) {
  const canApprove = repair.status === "proposed";
  const canVerify = repair.status === "approved";
  const isDone = ["verified", "verification_failed", "rejected"].includes(repair.status);

  if (repair.status === "manual_review_required") {
    return (
      <div className="panel">
        <div className="paneltitle"><b>Repair Proposal</b><span style={{ color: "#f97316" }}>Manual Review Required</span></div>
        <p style={{ marginTop: 8, color: "#8d9aad" }}>{repair.reason}</p>
        <p style={{ marginTop: 8, fontSize: 12 }}>This finding cannot be safely repaired automatically. A developer must review and implement the fix manually based on the recommendation.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="panel">
        <div className="paneltitle">
          <b>Repair Proposal</b>
          <span style={{ color: STATUS_COLORS[repair.status] || "#78a7ff" }}>{repair.status.toUpperCase().replaceAll("_", " ")}</span>
        </div>
        <p><b>Finding:</b> {repair.finding?.title}</p>
        <p><b>File:</b> <code style={{ fontSize: 11 }}>{repair.file}</code></p>
        <p><b>Description:</b> {repair.description}</p>
        <p><b>Risk:</b> {repair.risk}</p>

        {!isDone && (
          <div className="actions" style={{ marginTop: 14 }}>
            <button onClick={onViewDiff} disabled={actionLoading}>VIEW DIFF</button>
            {canApprove && (
              <>
                <button className="primary" onClick={onApprove} disabled={actionLoading}>
                  {actionLoading ? "…" : "APPROVE"}
                </button>
                <button onClick={onReject} disabled={actionLoading} style={{ color: "#f87171", borderColor: "#7c1f2e" }}>
                  REJECT
                </button>
              </>
            )}
            {canVerify && (
              <button className="primary" onClick={onVerify} disabled={actionLoading}>
                {actionLoading ? "VERIFYING…" : "RUN VERIFICATION"}
              </button>
            )}
          </div>
        )}

        {repair.status === "rejected" && (
          <p style={{ marginTop: 12, color: "#f87171", fontSize: 13 }}>✗ Repair rejected. Workspace cleaned up.</p>
        )}
        {repair.status === "verified" && (
          <p style={{ marginTop: 12, color: "#73d6a2", fontSize: 13 }}>✓ Repair verified successfully.</p>
        )}
        {repair.status === "verification_failed" && (
          <p style={{ marginTop: 12, color: "#f97316", fontSize: 13 }}>⚠ Verification failed. See Verification panel for details.</p>
        )}
      </div>

      {diffData && (
        <div className="panel" style={{ marginTop: 14 }}>
          <div className="paneltitle"><b>Diff</b><span>{diffData.file}</span></div>
          <DiffViewer diff={diffData.diff} />
        </div>
      )}
    </div>
  );
}

// ─── Diff Viewer ──────────────────────────────────────────────────────────────

function DiffViewer({ diff }) {
  if (!diff) {
    return <p style={{ color: "#66758a", fontSize: 13, padding: "8px 0" }}>No diff available (file may be new or unchanged).</p>;
  }
  return (
    <pre style={{
      background: "#070b12",
      border: "1px solid #1b2534",
      borderRadius: 8,
      padding: 14,
      overflowX: "auto",
      fontSize: 12,
      lineHeight: 1.7,
      fontFamily: '"SFMono-Regular", Consolas, monospace',
      margin: 0,
    }}>
      {diff.split("\n").map((line, i) => {
        let color = "#8d9aad";
        if (line.startsWith("+") && !line.startsWith("+++")) color = "#73d6a2";
        else if (line.startsWith("-") && !line.startsWith("---")) color = "#f87171";
        else if (line.startsWith("@@")) color = "#78a7ff";
        else if (line.startsWith("---") || line.startsWith("+++")) color = "#dce7f5";
        return <span key={i} style={{ color, display: "block" }}>{line}</span>;
      })}
    </pre>
  );
}

// ─── Verification View ────────────────────────────────────────────────────────

function VerificationView({ verification }) {
  const statusColor = { passed: "#73d6a2", failed: "#f87171", partial: "#f97316" }[verification.status] || "#78a7ff";
  const b = verification.before_metrics;
  const a = verification.after_metrics;
  const imp = verification.improvement;

  return (
    <div>
      <div className="panel">
        <div className="paneltitle">
          <b>Verification Result</b>
          <span style={{ color: statusColor, fontWeight: 700 }}>{verification.status.toUpperCase()}</span>
        </div>
        <p style={{ marginBottom: 12 }}>{verification.summary}</p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
          <MetricCompare label="Health Score" before={b.health_score} after={a.health_score} unit="/100" higherBetter />
          <MetricCompare label="Total Findings" before={b.total_findings} after={a.total_findings} higherBetter={false} />
          <MetricCompare label="Technical Debt" before={b.technical_debt_hours} after={a.technical_debt_hours} unit="h" higherBetter={false} />
          <MetricCompare label="Critical Findings" before={b.severity_counts?.CRITICAL || 0} after={a.severity_counts?.CRITICAL || 0} higherBetter={false} />
        </div>
      </div>

      <div className="panel" style={{ marginTop: 14 }}>
        <div className="paneltitle"><b>Verification Checks</b></div>
        {verification.checks.map((c, i) => (
          <div key={i} style={{
            display: "flex", gap: 12, padding: "10px 0",
            borderBottom: "1px solid #111a28", alignItems: "flex-start",
          }}>
            <span style={{
              fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 10,
              background: c.status === "passed" ? "#0d2818" : c.status === "failed" ? "#1e1020" : "#111a28",
              color: c.status === "passed" ? "#73d6a2" : c.status === "failed" ? "#f87171" : "#66758a",
              whiteSpace: "nowrap",
            }}>{c.status.toUpperCase()}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{c.name}</div>
              {c.output && (
                <pre style={{ fontSize: 11, color: "#66758a", marginTop: 4, background: "#070b12", padding: "6px 10px", borderRadius: 6, overflowX: "auto", whiteSpace: "pre-wrap" }}>
                  {c.output.slice(0, 500)}
                </pre>
              )}
            </div>
          </div>
        ))}
      </div>

      {verification.regressions.length > 0 && (
        <div className="panel" style={{ marginTop: 14, border: "1px solid #7c1f2e" }}>
          <div className="paneltitle"><b>Regressions Detected</b></div>
          {verification.regressions.map((r, i) => (
            <p key={i} style={{ color: "#f87171", fontSize: 13 }}>⚠ {r.description}</p>
          ))}
        </div>
      )}
    </div>
  );
}

function MetricCompare({ label, before, after, unit = "", higherBetter }) {
  const delta = (after ?? 0) - (before ?? 0);
  const improved = higherBetter ? delta >= 0 : delta <= 0;
  const deltaStr = delta === 0 ? "±0" : (delta > 0 ? `+${delta}` : `${delta}`);
  return (
    <div style={{ background: "#0d131e", border: "1px solid #1b2534", borderRadius: 8, padding: "10px 14px" }}>
      <div style={{ fontSize: 10, color: "#66758a", textTransform: "uppercase", letterSpacing: ".5px", marginBottom: 6 }}>{label}</div>
      <div style={{ display: "flex", gap: 10, alignItems: "baseline" }}>
        <span style={{ fontSize: 13, color: "#8d9aad" }}>{before}{unit}</span>
        <span style={{ fontSize: 11, color: "#66758a" }}>→</span>
        <span style={{ fontSize: 18, fontWeight: 700, color: "#dce7f5" }}>{after}{unit}</span>
        <span style={{ fontSize: 12, color: improved ? "#73d6a2" : "#f87171", fontWeight: 700 }}>{deltaStr}</span>
      </div>
    </div>
  );
}

// ─── Shared components ────────────────────────────────────────────────────────

function Metric({ label, value, trend }) {
  return (
    <div className="metric">
      <small>{label}</small>
      <strong>{value}</strong>
      <span>{trend}</span>
    </div>
  );
}

const STATUS_COLORS = {
  proposed: "#78a7ff",
  approved: "#73d6a2",
  rejected: "#f87171",
  verified: "#73d6a2",
  verification_failed: "#f97316",
};

// ─── Mount ────────────────────────────────────────────────────────────────────

createRoot(document.getElementById("root")).render(<App />);
